---
name: figure
description: Regenerate or adjust one figure in this repo — "redraw Figure 4", "make Fig 5 use the high-concentration scale", "why is cluster 5 blank in two mice?", "change which clusters Fig 4C shows". Knows the section-to-figure map, every FIG*_ parameter and its legal values, and the edit → rebuild → verify loop. Use for any request to change what a figure shows.
---

# Working on one figure

Every figure in the manuscript is drawn by one numbered section of
`notebooks/figures.py`. **The section number is the figure number.** There is
no per-figure script.

## Find the section

| § | Figure | Stem | Panel module |
|---|---|---|---|
| 1 | Setup — style, data, the PLS fit | — | — |
| 3 | **Fig 3** + its threshold supplement | `fig3_correlational_structure`, `fig3_supp_threshold_robustness` | `panels.similarity`, `panels.recruitment` |
| 4 | **Fig 4** — tuning change by cluster | `fig4_tuning_by_cluster` | `panels.clustering` |
| 5 | **Fig 5** — clusters on the dorsal bulb | `fig5_spatial_by_cluster` | `panels.clustering` |
| 6 | **Fig 6** — PLS-R | `fig6_pls` | `panels.pls`, `panels.similarity`, `panels.recruitment`, `panels.schematic` |
| 7 | **Fig 7** — motif transfer | `fig7_motif_transfer` | `panels.transfer` |
| 8 | **Fig S1** — NMF dimensionality | `supp_nmf_dim_choice` | `panels.dimchoice` |
| 9 | **Fig S2** — per-subject reproducibility | `supp_per_subject` | `panels.clustering` |
| 10 | **Fig S3** — flow through tuning space | `supp_tuning_flow` | `panels.flow` |
| 11 | **Fig S4** — model parity | `supp_parity` | `panels.pls` |

There is no §2 — the gap keeps §*n* drawing Figure *n*.

## Decide which layer to edit

Three layers, and picking the wrong one is the usual mistake:

- **A constant at the top of the section** — the section's `FIG*_` block. Most
  requests land here. Every section owns its constants and shares no bare name
  with another, so changing one cannot leak into a different figure.
- **Composition, in the notebook cell** — grids, colorbars, panel letters,
  figure size. Layout requests land here.
- **A panel function in `highconc/panels/`** — what a panel *draws*. Editing
  one changes **every figure that uses it**; check before you do. Panels take
  an `ax`, never create a figure, never save, never load data.

Analysis lives in `highconc/*.py` and returns numbers. If a request needs a
different *number*, it belongs there — but see the invariants below first.

## The parameters, by section

**§3 — Figure 3**
- `CLASS_ORDER_FIG3` — `"table"` | `"matt"` | `"matt_esters_first"`. Block
  order of the chemical classes. Default `"matt"`, which is the order the
  draft panels are drawn in; changing it changes every block-ordered panel.
- `WITHIN_CLASS_ORDER` — `"table"` | `"matt"`. Affects the pyrazine block only.
- `SPECTRUM_SCALE` — `"per-panel"` | `"shared"`. Whether 3E/F/G autoscale
  individually or share one limit via `P.shared_spectrum_limit`.
- `EG_GLOMERULI` — the three example glomeruli, from
  `similarity.EG_GLOMERULI`. **Fig 6B–D must reuse the same three.** Do not
  change one without the other.
- `ROW_RULE_FIG3` (`"halfmax"`), `ROW_FRAC_FIG3` (`0.50`),
  `PRED_THRESHOLD_FIG3` (`"rate_matched"`) — the recruitment rule. §6 restates
  the same values for Figure 6E; keep them in step.
- `SWEEP_FRACS_FIG3` — the five thresholds in the supplement.

**§4 — Figure 4**
- `FIG4_VMIN`, `FIG4_VMAX` = `1, 140` — dF/F colour range of the response
  heatmaps. `FIG4_CMAP = "OrRd"`, `FIG4_EMPTY = "gainsboro"` for below-vmin.
- `FIG4_CONC_A` — `"low"` | `"high"`. Which concentration panel A shows.
- `FIG4C_CLUSTERS` — currently `(1, 3)`. Which two clusters panel C draws.
- `FIG4_THRESHOLD` = `0.5` — fraction of the per-glomerulus max that counts as
  a response. `FIG4_NORM = "joint"` normalises across both concentrations;
  `FIG4_AGGREGATE = "mean"`.
- `FIG4_SUMMARY_VMAX` is **computed** as the max over both concentrations, so
  low and high stay comparable and the high row filling in reads as broadening.
  Do not replace it with a literal.

**§5 — Figure 5**
- `FIG5_CONC` — `"low"` | `"high"`.
- `FIG5_NONRESPONDER` — `"requested"` | `"context"` | a dict of scatter kwargs.
- `FIG5_CLUSTER_SIZE`, `FIG5_CLUSTER_EDGE`, `FIG5_CLUSTER_LW` — the cluster's
  own points, drawn on top.
- `FIG5_TOPO_VMIN` / `FIG5_TOPO_VMAX` — restated from
  `P.clustering.TOPO_VMIN/VMAX` (`0.0, 5.0`). **Shared across all seven maps**,
  or comparing them stops meaning anything. See `/restyle` before touching.

**§6 — Figure 6**
- `FIG6_SPACE` — `"log"` | `"sqrt"` | `"raw"`. `"log"` is the log1p space the
  model is fitted and scored in, and is the default for that reason. **Do not
  flip it without reading the note in the section's markdown** — this one has
  been argued out already.
- `FIG6_LIMIT` — `None` autoscales each panel, as 3E/F/G do.
- `FIG6_SUPPORT_THRESHOLD` = `0.4` — above this a bar counts as a response;
  the notebook prints both support counts under the figure every run.
- `FIG6_PRED_THRESHOLD` = `"rate_matched"`, `FIG6_ORDER = "matt"`,
  `FIG6_TOP_K = 85`, `FIG6_CANONICAL = "baseline"`.
- `FIG6_W`, `FIG6_H`, `FIG6_GAP` and the `*_BOT`/`*_TOP` names below them are
  layout in centimetre-like units. `FIG6_GAP` between row blocks is the one
  that matters.

**§7 — Figure 7**
- `FIG7_METRIC` — `"pct_err"` | `"pct_var"` | `"dq2"`.
- `FIG7_ALPHA` = `0.05` — the BH-FDR level drawn as black boxes.
- `FIG7_CLIP` = `0.1`, `FIG7_NULL = "broken_pairing"` (the published null),
  `FIG7_MIN_CLASS = 15` glomeruli for a chemical class to be tested.

**§8–§11 — supplements**
- `SUPP_DIM_K_VALUES` = `range(1, 21)` — **this is the sweep that is on disk.**
  Changing it invalidates the cache and the figure will raise.
- `SUPP_SUBJ_HEAT_VMIN/VMAX` = `1.0, 140.0`; `SUPP_SUBJ_LABEL_FS`,
  `SUPP_SUBJ_TITLE_PAD`.
- `SUPP_FLOW_SHOW` = `(2, 3, 4, 7)` — which clusters are drawn in 3-D. **The
  statistic uses all seven regardless.** `SUPP_FLOW_VIEW` is the locked camera.
- `SUPP_PAR_CLASS_ORDER` = `"table"`.

## The loop

1. Edit `notebooks/figures.py` — **never** `figures_human.*` or
   `figures_LLM.*`, which are generated and will be overwritten.
2. Rebuild the editions and verify:
   ```bash
   python dev/build_notebooks.py
   ```
3. Re-render and check. Use `/verify` for the full gate, or for a quick look
   run §1 and then just that figure's section in a kernel.

A figure's caption lives in the source twice, tagged `human` and `llm`. **If a
change alters what the figure shows, update both captions** — they sit next to
the code so the two cannot drift.

## Invariants — say no rather than break these

- **Cluster numbering is 1–7.** The legacy A–G letters survive only as a
  mapping in `highconc.clusters` and **do not map in order**. A letter does not
  tell you the number.
- **Nothing is refitted at draw time.** `dimsweep.load_cached` and
  `highconc.pls.load_weights` / `.component_selection` / `.lv_loadings` read
  from disk and **raise** on a miss. If you hit that exception, the fix is to
  restore the cache, not to make it recompute — a silent recompute is how the
  notebook stops matching the paper.
- **Fig 3B, 3C and 4A share a 0–1 correlation scale.** They are only comparable
  because of it.
- **Fig 6B–D must use the same three example glomeruli as Fig 3E/F/G.**
- **Figures 3A, 4E, 5B–D and Figure 7's explanatory header are drawn
  elsewhere.** They are recorded as `skipped` in `dev/CONCORDANCE.yaml`. Do not
  "fill them in".
- **The figure set is fixed by `dev/CONCORDANCE.yaml`.** Adding a figure means
  adding it to the manifest with a reason, or `concordance.py --check` fails it
  as scope creep. Removing one fails as unfinished work.
- **Never edit a render by hand.** If a figure needs touch-up, the touch-up
  belongs upstream in the code.

If a request is incompatible with one of these, say so and explain which —
do not quietly produce a figure that no longer matches the manuscript.

## A different skill you may also see

`style/for-collaborators/claude-skill/highconc-figure/` is a **separate,
older skill with a different job**: turning an arbitrary data file — a CSV,
an `.npy` — into a house-style panel, for someone working *outside* this repo.
It is installed into `~/.claude/skills/` by
`style/for-collaborators/install-claude-skill.sh`, and it treats
`style/STYLE_GUIDE.md` as its authority.

Use **this** skill for anything inside `highconc-figures`: the figures here are
already built, and the work is editing a section of `notebooks/figures.py`, not
plotting a file from scratch.
