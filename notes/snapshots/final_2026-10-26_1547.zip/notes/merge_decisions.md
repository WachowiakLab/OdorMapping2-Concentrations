# Merge decisions

Baseline: `github/original_codebase`. Versions: `lab` = highconc-figures-lab,
`main` = highconc-figures-lab-main, `copy` = highconc-figures-lab-main - Copy.
`joel_figures` is dropped (user decision): never copied, never exported.

`final/` is seeded with the baseline. Figure sections are assembled from the
choices below once the per-figure pass is done; generated files
(`figures_human.*`, `figures_LLM.*`) are rebuilt with `dev/build_notebooks.py`,
never merged.

## §1 Setup  — decided

Source: `main` setup cell (it is a strict superset of `copy`; `lab` changed nothing).
Changes on top of it:

- Remove the `JOEL_FIGURES` folder, its `_write(...)` call, and its docstring/print mentions.
- Remove unused `import os`.
- Drop `mpl.use("Agg")` (keeps inline display as in the baseline; use `MPLBACKEND=Agg` for headless runs).
- Keep `import pandas as pd`, `MAIN_TARGET_W = 7.0`, `SUPP_TARGET_W = 5.5`,
  `CLASS_STRIP_FONTSIZE`, `HEATMAP_TITLE_FONTSIZE` and their explanatory comment
  (exact-width figure scaling is the standard; assumed, not yet explicitly confirmed).

## §2 Figure 2 (odorant x glomerulus response, Burton's own data) — decided

Only in main/copy. Source: **main's `figures_human.py`** code cells (live, newest).
main's `figures.py` has the whole section commented out; main's `figures_LLM.py` has no §2 code;
copy's `figures.py` is live but older.

- Put the live code into final `figures.py`, uncommented.
- Drop the dead `# cax = fig.add_axes([0.84, 0.15, ...])` line and the two commented `export_figure` examples.
- Prose (both editions) identical in main and copy: keep.
- Needs main's `highconc/panels/similarity.py` (`strip_fontsize` option) and `similarity.burton_response_matrix`
  (in main and copy, not in baseline), plus `data/burton_et_al/*.csv` (identical in main and copy)
  and the `fig2_response_matrix` entry in `dev/CONCORDANCE.yaml`.

## §3 Figure 3 (odorant-odorant similarity) — decided, one item open

Assembled code: `final/notes/sections/03_fig3_code.py` (built from copy's `figures.py` by
`build03.py`; syntax-checked, NOT yet run). Choices:

- Layout: **copy's** (14 x 11.6 in, 3x4 grid, `FIG3_PANEL_ORDER = "DABC"`, panel A = "most sensitive").
  NOT main's inch-based redesign, so Fig 3 does **not** hit `MAIN_TARGET_W` and has no green
  diagonal boxes (`FIG3_BOX_*`) — consequence of this choice, not yet raised with the user.
- Chemical-family strip labels on **all four** matrices A-D (`strip_labels=True`).
- `CLASS_ORDER_FIG3 = "matt"`, `WITHIN_CLASS_ORDER = "matt"` (copy and main had `"burton"`).
- 4th example glomerulus from lab (`EXTRA_GLOM`, subject 1, #8): spectra are E-H,
  recruitment matrix becomes **I**. Not in `EG_GLOMERULI`, so Fig 6 is unaffected.
- NOT ported from lab: `SPECTRUM_YLIM(S)` options and fixed spectrum size/fonts (not requested).
- Recruitment rule (decided by user): **main's** — `ROW_FRAC_FIG3 = 0.20`, `LO_FRAC_FIG3 = 0.20`,
  `recruitment_matrix(..., lo_threshold=LO_FRAC_FIG3, ...)` and the same in the S-sweep
  (`matrix_sweep(..., lo_threshold=...)`). `row_rule` / `prediction_threshold` are gone from §3.
  **Consequence:** this requires main's rewritten `highconc/recruitment.py` (`lo_threshold`
  kwarg); copy's and the baseline's do not take it. Check Fig 6 (and anything else calling
  `recruitment_matrix` / `matrix_sweep`) when merging that module.
- Do NOT take lab's `highconc/similarity.py`: its 3-line change splits `_clusters` into
  `_cluste` / `rs` (syntax error).
- Needs copy/main's `similarity.most_sensitive_correlation`, `similarity.split_block`,
  `cl.AROMATIC_SUBCLASS_BY_CODE`, `recruitment_matrix(..., within=, codes=)`.

## §4 Figure 4 (glomerular groups, tuning by chemical class) — decided

Assembled code: `final/notes/sections/04_fig4_code.py` (from **main's `figures.py`**, which is newer
than main's `figures_human.py`; built by `build04.py`; syntax-checked, NOT yet run).
Panel code written to `final/highconc/panels/clustering.py` (= main's file + patch, see below).

- **A, C:** main (green cluster boxes; C rows in chemical-class order with white class lines).
  lab's C change is subsumed by main's; lab's own 14-line `panels/clustering.py` edit
  (half-finished `norm`/`normalize` args) is dropped.
- **B:** rows ordered by class `"matt"` and within-class `"matt"` (`within_order=WITHIN_CLASS_ORDER`),
  column-normalised (peak per glomerulus, linear 0-1, `raw_floor = FIG4_VMIN`), class names on rows,
  diagonal highlight off. Colormap `magma` (copy and main).
- **C:** same row order as B (asserted equal to B's rows in the cell) and same normalisation.
  Needed a **new patch**: `per_subject_heatmap` gained `col_normalize` / `raw_floor` (default off, so
  S2's use is unchanged), same logic as `biclustered`. B's colorbar serves C.
- **D:** main's `class_cluster_glom_composition` metric, low and high each normalised within their own
  concentration (each cluster column / its top class) with their own colorbar; writes
  `fig4_tuning_by_cluster_D_glom_composition.csv`. Copy's `class_cluster_composition` and
  `activation_fraction` are dropped (not called anywhere in main's notebook).
- **Width:** main's exact `MAIN_TARGET_W` (7.0 in) — user did not answer; assumed, same as §1 (c).
- **To do at assembly:** add `import dataclasses` to §1 (main's notebook uses `dataclasses.replace`
  in §4 but never imports it).

## §5 Figure 5 (clusters on the dorsal bulb) — decided

No conflict: baseline, lab and copy notebook code identical; only main changed it.
Assembled code: `final/notes/sections/05_fig5_code.py` (from main's `figures.py`; `build05.py`;
syntax-checked, NOT yet run).

- Keep main's formatting: hollow non-responders, black outline, exact `MAIN_TARGET_W` width with
  marker sizes/line widths rescaled.
- **User change:** every cluster member is one solid **red** (`FIG5_MEMBER_COLOR = "red"`), showing
  membership only — no dF/F is encoded.
  - Panel patch in `final/highconc/panels/clustering.py`: `topography(..., color=None)`; when set, members
    are one solid colour and `conc/vmin/vmax/cmap` are ignored. Default behaviour unchanged.
  - Consequences, made by me: colourbar and its "mean dF/F" label removed; `FIG5_CONC` and the row label
    "low" removed (membership has no concentration); gridspec `right` 0.90 -> 0.97 since the colourbar
    margin is gone. Caption/legend text for Fig 5 still says "mean dF/F" if it does — check at prose pass.
- Related, for the analysis step: lab's `spatial_statistics.svg`, `smoothed_cluster_spatial_overlap.svg`
  and main's `dev/spatial_autocorrelation.py` look like Fig 5 spatial analyses.

## §6 Figure 6 (PLS-R) — decided: NEW DESIGN, not any version's

User decision: one row, **panels C and D only**.
Assembled: `final/notes/sections/06_fig6_code.py` (new code, based on main's `figures.py`;
`build06.py`; syntax-checked, NOT run, layout NOT seen — see environment note below).

- **C:** two example glomeruli, ids **211 and 97** (dataset glomerulus ids), experimental high up /
  predicted high down, `FIG6_SPACE = "log"`, class labels on both, stacked on the left.
  Horizontal line = smallest **nonzero** observed high response over the whole dataset in log space
  (computed by new `pls.observed_high_floor`; replaces main's hard-coded `-1.538585657976575`). Plain
  min is always 0 because `_to_space` clips at 0. User did not say per-panel vs dataset-wide: I used
  dataset-wide (one shared line). Drawn at the mirrored (negative) position, like main's line.
- **D:** the W matrix with **every weight** (no `FIG6_TOP_K` / `top_weight_gloms` cut). Colour range
  still each sign at its 99th percentile (a display scale, not a data cut) — not asked about.
- **Dropped:** old A, B (Fig 3 glomeruli), old D (recruitment matrix), E (retuning cartoons),
  `FIG6_ROW_FRAC/LO_FRAC`, the recruitment CSV exports, and the "6A/B/C vs 3E/F/G" parity cell
  (211/97 are not Fig 3's glomeruli). Only `fig6_pls_C_prediction_spectra.csv` is exported.
  `schematic` (retuning cartoons) is now unused by Fig 6 — check whether anything else uses it.
- Width: `MAIN_TARGET_W` exactly (7.0 in); layout in inches, height 3.5 in; right margin is derived.
- Code written into `final/`: `highconc/pls.py` (= main's + `observed_high_floor`) and
  `highconc/panels/similarity.py` (= main's + `observed_floor` option on `prediction_spectrum`).
- **Panels C/D letters** are C and D as the user said (not A/B). Fig 6 in the manuscript may need
  renumbering later (Step 4).
- **Manifest:** `dev/CONCORDANCE.yaml` must list only the new Fig 6 panels (C, D), with the dropped
  ones recorded as skipped/removed, or `concordance.py --check` will fail.

## §7 Figure 7 (motif transfer) — decided by user, one item open

Assembled: `final/notes/sections/07_fig7_code.py` (from main's `figures.py`; `build07.py`;
syntax-checked, NOT run). Panel code: `final/highconc/panels/transfer.py` (baseline file + patch).

- **Only A and B** (the cluster row). C and D (chemical-class control) are no longer drawn; the
  class analysis, `matching_edges` control and intra-Q² prints are still computed and printed
  (not asked to remove — can be dropped, along with `FIG7_MIN_CLASS`).
- **Significant squares are boxed in green** (`FIG7_BOX_COLOR = "#2b9743"`, main's green) — I read
  "green for significance" as the existing box outline, not a fill. lab used plain `"green"`.
- **Only significant squares carry a value** (new `text_significant_only`).
- Labels: x = `cluster (predicted at high)` on A and B; y = `added non-source cluster\nprediction
  improvement` on A only (B had no y label before; I left it). Fixed the typo "predictin".
- Width `MAIN_TARGET_W` (7.0 in), one row, base height 6.0 (so ~3.2 in tall); layout NOT seen.
- Panel patch adds `box_color` + `text_significant_only` to `cell_grid` (passed through `**kw`) and
  `box_color` to `significance_legend`. This is lab's `box_color` idea, not main's hard-coded green.
- **Correction to an earlier message of mine:** analysis `highconc/transfer.py` is identical in all
  versions and the baseline; only `panels/transfer.py` differs (lab 18 lines, main 6, copy 0).
- lab's notebook also had muted colour ramps (`FIG7_MUTE = 0.35`, p panel and B both) and
  every matrix at a fixed 1.56 in with 2-line axis labels. **User: keep the original colormap**, so none
  of lab's Fig 7 colour/size changes are taken (fixed-size matrices not addressed; not taken).
  A and B use `hs.SEQ` (p) and `hs.DIV` (B) as the style module defines them — which `SEQ` that is
  (baseline OrRd vs main/copy magma) is decided in the `style.py` merge, not here.

## §8 Figure S1 (NMF dimensionality choice) — decided

No conflict: baseline, lab and copy identical; only main changed it (exact `SUPP_TARGET_W` = 5.5 in width).
Assembled: `final/notes/sections/08_figS1_code.py` (from main's `figures.py`; `build08.py`;
syntax-checked, NOT run). `panels/dimchoice.py` and `dimsweep.py` are identical in every version.

- **User: only A, B, C** = the 1x block (variance explained, variance slope, ARI stability). The 25x
  block (D-F) is dropped; its cache stays on disk and is not read.
- The unlettered consensus matrices beside C stay (part of the same strip) — my reading, not stated.
- Height 12.5 -> 5.5 in-equivalent (x `SUPP_DIM_SCALE`); the `ax_var` title still says
  "1x concentration - chosen k = 7". Layout NOT seen.
- **OPEN (global):** `hs.SEQ` is OrRd in baseline/lab and magma in copy/main. Fig 4 asks for magma; Fig 7
  A uses `hs.SEQ` and the user said "keep the original colormap" — unclear if that means OrRd. Resolve
  in the `style.py` merge; pinning Fig 7 A to OrRd explicitly is possible.

## §9 Figure S2 (per-subject structure) — decided; SPLIT INTO TWO FIGURES

Assembled: `final/notes/sections/09_figS2_code.py` (`build09.py`; syntax-checked, NOT run, layout NOT seen).
Outputs two figures, no panel letters (each stands alone): `supp_per_subject_heatmaps` (was A) and
`supp_per_subject_topography` (was B). Needs `dev/CONCORDANCE.yaml` to list both and drop `supp_per_subject`.

- Sources: baseline = copy; lab changed A; main changed B + scaling to 5.5 in.
- **A (heatmaps):** lab's design — rows in chemical-class order, linear raw dF/F 0-100 in magma, white
  boundaries, class strip on the first heatmap, y label "odorants (by chemical class)". User: ordering
  **'matt' / 'matt'** like Fig 4 (`SUPP_SUBJ_ODOR_ORDER = CLASS_ORDER_FIG3`, `..._WITHIN = WITHIN_CLASS_ORDER`),
  not lab's hard-coded `("matt", "table")`. **Scale: user chose LOG (dF/F 1-140, ticks 1/10/100), not lab's
  linear 0-100.** Colormap stays magma (lab's; matches Fig 4) — user did not comment on the colormap.
  Width `SUPP_TARGET_W` (5.5 in), fonts as main (7 pt title, 5 pt y label).
- **B (topography):** "exact formatting as Figure 5, colours changing by cluster" — I read it as: Fig 5's marker
  size, black outline width, hollow pale-grey context (darkgray at alpha 0.5), same page scale; members keep
  their per-cluster fill (not Fig 5's red). Consequence: B is **7.0 in wide** (`MAIN_TARGET_W`), not the
  supplement's 5.5 in, so the maps are Fig 5's size; height 5.2 in is a guess.
  Also: main's "marker size / 2" styling is replaced by Fig 5's numbers.
- Panel patch in `final/highconc/panels/clustering.py`: `per_subject_topography(context_alpha=None)` only.
  (An earlier `per_subject_heatmap(norm=...)` patch for lab's linear scale was removed once log was chosen.)
- **To do at assembly (§1):** add `import dataclasses` (used by §4 and §9).

## §10 Figure S3 (direction of change through tuning space) — SKIPPED

User: not in the current draft. Nothing assembled. Open consequences, to handle at assembly:
- Decide what `final/notebooks/figures.py` does with §10: remove the section (keeping §11 numbered as is,
  since "section number = figure number") or leave the baseline cell. Not decided; user's call.
- `dev/CONCORDANCE.yaml` must record S3's outputs as skipped/removed or `concordance.py --check` fails.
- `highconc/flow.py` and `highconc/panels/flow.py` would be unused. main/copy changed `flow.py` (17 lines);
  that edit is therefore moot unless S3 returns. Keep the modules; do not delete.

## §11 Figure S4 (parity of the linear model) — decided on my reading of an earlier user message

Assembled: `final/notes/sections/11_figS4_code.py` (`build11.py`; syntax-checked, NOT run, layout NOT seen).
Panel patch: `final/highconc/panels/pls.py` (baseline file + `responding_parity(cmap=None, floor=None, floor_color)`).

- **Only panel C** (parity of all responding pairs, hexbin); A and B (cluster x odorant, cluster x class)
  are dropped, with their `cluster_by_odorant` / `class_by_cluster` calls. Single panel, no letter, stem
  `supp_parity` kept, `SUPP_TARGET_W / 2` x 2.4 in (a guess, layout not seen).
- **Purples** hexbin colormap, via `SUPP_PAR_C_CMAP = "Purples"` in the cell. main hard-coded `"Purples"` inside
  the panel; I did NOT take that (colours should not be hard-coded in panels) — made it a `cmap` argument.
- **Dotted horizontal line** at `pls.observed_high_floor(m, "log")` (smallest nonzero observed high response,
  the same value as Fig 6C's line) — `floor=` option on the panel. Predictions below it are below anything
  measured. I read "dotted horizontal line for under the observed minimum" this way.
- **Provenance of this decision:** the user's earlier message "First, only part C. Purples color map and a dotted
  horizontal line for under the observed minimum" arrived while S2 was on screen; I first took it as Fig 6.
  Finding main's hard-coded Purples in S4's panel suggests it was about S4. If it was about Fig 6, redo.
- Copy and main (`SUPP_PAR_CLASS_ORDER = "matt"`) only affected A/B, now moot. main's 5.5 in scaling not used
  (single panel). lab's change: C colormap magma (`cmap` param) and `ax.set_aspect("equal", "box")` in the
  panel — the aspect change is NOT taken (not requested).
- **lab's extra ~270 lines in §11** (Ripley's K, Moran/Geary autocorrelation, k-sweep; new deps `esda`,
  `libpysal`; placeholder `gini`; saves nothing) are NOT part of S4 and NOT assembled here. Deferred to the
  `analysis` step together with main's `dev/spatial_autocorrelation.py` (a separate implementation of the
  same statistics). `esda`/`libpysal` are not installed in this Python.

## Shared modules and tooling — decided and APPLIED to `final/` (script `shared.py`)

Taken from **main** unchanged (copy == main; lab unchanged or corrupt): `highconc/similarity.py`,
`clusters.py`, `flow.py`, `recruitment.py`, `panels/recruitment.py`, `panels/__init__.py` (drops the
`activation_fraction` export, matching main's `panels/clustering.py`), `dev/build_notebooks.py`
(explicit UTF-8 — the likely cause of lab's mojibake). Also `data/burton_et_al/*` (4 csv + odorant_order.txt;
NOT main's stray `test.ipynb`).

- `style.py` = main's (**`SEQ = magma` globally**, `class_strip(side=...)`) + lab's `class_strip(offset=...)`.
- Fig 4B's class strip now passes `offset=0` (seaborn heatmap: row i spans i..i+1). Main's default would have
  put it half a row off — my inference, confirm when rendered.
- **Fig 7 A pinned to OrRd** (`FIG7_P_CMAP`, new `cmap` option on `pvalue_matrix`): I read "keep the original
  colormap" as the baseline's. B uses `hs.DIV` (unchanged in every version).
- `pyproject.toml`: private deps `git+ssh://git@github.com/...` -> `git+https://github.com/...` (main wrote
  `git+https://git@github.com/...`; I dropped the odd `git@` user). README wording SSH -> HTTPS. `lab`'s `spatial`
  extra (esda/libpysal/pointpats) NOT added — analysis step.
- `.claude/settings.json`: baseline's exact commands + PowerShell mirrors. Dropped main's wide `:*` prefixes
  and `dev/where.py` (that file exists in no version).
- `.gitignore`: left as the baseline (no `joel_figures/` line).
- `data/pls_results/baseline/component_selection.json` and all other data/cache files: identical in every
  version (lab's differs only by CRLF). Nothing to merge.
- `environment.yml`: main's only change was a missing trailing newline; not taken.
- **Check run:** every `.py` in `final/` parses, and `highconc` + all its modules and panels import with
  `glom_explorer`/`pls_explorer`/`plotly` stubbed. This is an import check, NOT a figure render.

## STITCHED: `final/notebooks/figures.py` written (2026-10-26)

`stitch.py` built it: main's `figures.py` as the skeleton (its Fig 2 section, intro and section layout), code
cells replaced cell-for-cell from `notes/sections/*.py`, §1 edited (import `dataclasses`; removed
`mpl.use("Agg")`, `import os` and all `JOEL_FIGURES` code), Fig 2 taken live from main's `figures_human.py`
(dead `cax` line and export examples dropped), **§10 (S3) removed** (my recommendation; the user had not yet
answered "remove or keep the baseline cell" — easy to restore from the baseline `figures.py`).

- 53 cells. Compiles as one script; no name is read without being bound (AST check). Not executed.
- `figures_human.py` and `figures_LLM.py` regenerated with the repo's own `parse_cells`/`render`
  (`build_notebooks.py --check` says both are current).
- **STALE:** `notebooks/figures_human.ipynb` and `figures_LLM.ipynb` are still the BASELINE's (with the old
  figures' outputs). Regenerating them needs `jupytext`, which is not installed here; I did not install it.
  Run `python -m pip install jupytext` then `python dev/build_notebooks.py`.
- **Captions are stale.** Every changed section's markdown starts with a visible line
  "[Caption not yet updated for the merged figure ...]" (sections 3, 4, 5, 6, 7, 8, 9, 11). The intro/table of
  contents (cells 0-1) also still describe the old figure set; §3's supplement headings too.
- Build scripts that produced all of this are archived in `notes/build_scripts/` (they read scratchpad
  split files and the original folders, so they document the process rather than re-run standalone).

## Still to do (not yet applied)
1. Stitch `notes/sections/*` into `final/notebooks/figures.py` (+ §1: `import dataclasses`, drop `JOEL_FIGURES`,
   `mpl.use("Agg")`, `import os`). §10 (S3): remove or keep — user to say.
2. `dev/CONCORDANCE.yaml`: baseline ids are `fig3 fig3_supp fig4 fig5 fig6 fig7 supp_dim_choice supp_per_subject
   supp_tuning_flow supp_parity`; needs fig2, the two S2 stems, panel lists for 6/7/S1/S4, S3 skipped.
3. Captions (human + LLM) for every changed figure; `.claude/skills/*/SKILL.md` and `style/` docs mention
   removed constants and OrRd.
4. Rebuild the two notebook editions; render; `concordance.py --check`; `build_notebooks.py --check`
   (needs an environment where the private packages install).
5. `analysis\` folder, then manuscript renumbering.

## Environment note

`glom_explorer` and `pls_explorer` (private repos) are **not installed** in this Python, so nothing
can be rendered or run here yet. All assembled code is syntax-checked only. Nothing about layout,
overlap or visual results has been seen. First full run must be done where those packages install.

## Findings to remember

- `lab`'s `figures_human.py` is not valid UTF-8 (mixed cp1252 / mojibake). Do not merge from it; write UTF-8 in `final/`.
- Every folder's `figures_human.py` / `figures_LLM.py` code differs from its own `figures.py`
  (stale or hand-edited), so check them per figure before discarding.

## Pending

- Fig 2 (only in main/copy), Fig 3 … S4, shared modules, dev tooling, pyproject/environment.
