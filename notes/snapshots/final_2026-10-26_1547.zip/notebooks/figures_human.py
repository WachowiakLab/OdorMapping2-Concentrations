# %% [markdown]
# <!-- GENERATED FILE — do not edit. Source: notebooks/figures.py.
#      Rebuild with `python dev/build_notebooks.py`. -->
#
# *This is the **human** edition of the figure notebook — the friendly one — what each figure shows, and how it was made.*
# *Same code, same figures, different words: the other edition is `figures_LLM`.*
# *Edits go in `notebooks/figures.py`, never here — this file is overwritten.*

# %% [markdown]
# # High-concentration odor mapping — the figures
#
# This notebook draws every figure in the paper, except for a small handful
# that only Matt has the data for. Run it top to bottom and it rebuilds all of
# them into `notebooks/outputs/` as PNG, PDF and SVG.
#
# ### The basic story the figures tell
#
# - Raising concentration changes which odorants evoke similar glomerular
#   response patterns, not only how strongly they respond (**Fig 3**).
# - Glomeruli group by shared odorant preference, and tuning broadens with
#   concentration (**Fig 4**); the groups map onto the bulb (**Fig 5**).
# - A linear model fitted across all odorants predicts held-out
#   high-concentration responses (**Fig 6**).
# - The broadening is selective and asymmetric: particular groups take on the
#   tuning of particular others, and not the reverse (**Fig 7**).
#
# ### What's in here
#
# Section numbers are the paper's figure numbers, so §3 draws Figure 3.
#
# | § | Figure | In one line |
# |---|---|---|
# | 1 | setup | Loads the data and fits the model. Run this first. |
# | 2 | **Fig 2** | Odorant tuning across Burton's own glomeruli, both concentrations |
# | 3 | **Fig 3** | Odorant–odorant response similarity at both concentrations |
# | 4 | **Fig 4** | The seven glomerular groups, and tuning by chemical class |
# | 5 | **Fig 5** | Where those groups sit on the bulb |
# | 6 | **Fig 6** | A linear model predicting the low → high change |
# | 7 | **Fig 7** | Directional transfer of tuning between groups |
# | 8 | **Fig S1** | How the number of groups was chosen |
# | 9 | **Fig S2** | The same structure within each mouse |
# | 10 | **Fig S3** | Direction of change through tuning space |
# | 11 | **Fig S4** | Predicted vs measured, at three levels of averaging |
#
# §2 used to be empty — a model cartoon that lived there is drawn separately
# in Illustrator now — but Figure 2 (added 2026-09) has since filled it, so
# §*n* still means Figure *n* with no gap left in the numbering.
#
# A few panels in the paper are Matt's — the bulb photographs, the per-cluster
# spectra in Fig 4E, and Fig 7's explanatory header — and are not drawn here.
#
# ### How to change something
#
# - **A panel's contents** (what's plotted, its colours): edit the function in
#   `highconc/panels/`. Every figure using it follows.
# - **A figure's layout** (grid, colourbars, panel letters): edit the cell that
#   builds it, right here in the notebook.
# - **Fonts, colours, export settings**: `highconc/style.py`, once, for
#   everything. No cell sets its own.
#
# ### Two things that will bite you
#
# 1. **Run it in order.** §1 loads the data and fits the model that later
#    sections share. Running a later section on a fresh kernel refits it, which
#    takes about a minute.
# 2. **Some results are cached on disk and are not recomputed** — the model fit
#    and the dimensionality sweeps in §8. If a cache is missing the notebook
#    stops with an error instead of quietly recomputing, because a recomputed
#    number might not match the one in the paper.
#
# Glomerular groups are numbered **1–7** throughout. Older figures and drafts
# label them A–G; the letters do not map onto the numbers in order, so don't
# assume cluster C is cluster 3. `highconc.clusters` holds the translation.

# %% [markdown]
# ## 1. Setup
#
# Loads the imaging data and fits the model that most of the later sections use.
# Run this before anything else. It takes about a minute the first time and is
# then cached, so re-running costs nothing.
#
# The cell after the imports also explains **how to export figures** — the short
# version is that a normal run already writes PNG, PDF and SVG of everything.

# %%
import dataclasses
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm, PowerNorm, TwoSlopeNorm
from matplotlib.gridspec import GridSpecFromSubplotSpec
from matplotlib.lines import Line2D
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401  (registers the 3d projection)

from highconc import (
    clusters as cl,
    dimsweep,
    flow,
    load,
    pls,
    recruitment as rc,
    schematic,
    similarity,
    style as hs,
    transfer,
)
from highconc import panels as P

# Export contract (editable SVG text, TrueType in PDF), type scale, colours.
hs.apply()

# %%
# Where we are, and where renders go. `outputs/` is gitignored; the notebook can
# be re-run from a clean clone and will rebuild everything in it.
ROOT = next(p for p in [Path.cwd(), *Path.cwd().parents]
            if (p / "pyproject.toml").exists())
FIGURES = ROOT / "figures"
OUT = ROOT / "notebooks" / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

SAVE = True          # write png/pdf/svg to OUT as well as showing inline
FIG_DPI = 200        # raster preview density; vector formats are resolution-free
VARIANT = "nonresponders_dropped"

#: Every figure this notebook draws is scaled to span an exact physical
#: width: `MAIN_TARGET_W` for the numbered figures (2-7), `SUPP_TARGET_W`
#: for the supplements (S1-S4) -- smaller, and shared by all four rather than
#: each carrying its own inherited size. Each section solves its own
#: `*_SCALE` (or, for Fig 3, `FIG3_SCALE` applied to every margin/gap in the
#: section) so that section's own total width comes out to exactly the
#: target, then multiplies every other length in the section by that same
#: factor -- so raising or lowering either target here rescales every figure
#: in step, proportions held, no section needing a by-hand edit.
#:
#: This makes each figure's own physical size the invariant, at the cost of
#: an older one: before this, every section computed its scale from
#: `HEATMAP_IN` so that Fig 2 A-C, Fig 3 A-D/H, Fig 4 A-B, Fig 6 D, Fig 7 A,
#: S2's per-subject heatmaps and S3's coherence matrix all rendered at the
#: *same* physical size across figures. Two exact-width targets and one
#: shared heatmap size cannot both hold in general -- the figures' own
#: layouts (margins, panel counts, aspect ratios) differ too much -- so
#: pick one. `HEATMAP_PX`/`FIG_SCALE`/`HEATMAP_IN` below still set the
#: reference heatmap size a section's `*_SCALE` is *measured against*
#: (unchanged from before), but no longer guarantee it comes out identical
#: figure to figure once that section's scale is re-solved for its own
#: width target.
MAIN_TARGET_W = 7.0      # inches -- Figures 2-7
SUPP_TARGET_W = 5.5      # inches -- Figures S1-S4, smaller and shared
FIG_SCALE = 1.2
HEATMAP_PX = 260
HEATMAP_IN = HEATMAP_PX / FIG_DPI * FIG_SCALE

#: Chemical-class strip label size ("acids", "aldehydes", ...) on those same
#: panels -- small enough to fit next to a 0.6in heatmap without crowding it.
CLASS_STRIP_FONTSIZE = 5

#: Title size for the same panels. The house `FS_LABEL` (9pt) titles like
#: "'most sensitive'" are wider than a 0.6in/120px panel, so they overflow
#: into the next panel or the panel letter beside them; this is small enough
#: to mostly fit within one panel's width instead.
HEATMAP_TITLE_FONTSIZE = 7


EXPORT_FORMATS = ("png", "pdf", "svg")

#: Every figure this notebook has drawn, by stem, in the order drawn.
#: `save()` fills it; `export_figure()` reads it. Holding the figure objects
#: is what lets you re-export without recomputing anything.
DRAWN: dict[str, "plt.Figure"] = {}


def _write(fig, stem, outdir, formats, dpi):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    for ext in formats:
        fig.savefig(outdir / f"{stem}.{ext}", dpi=dpi,
                    bbox_inches="tight",
                    facecolor="white" if ext == "png" else "none",
                    transparent=(ext != "png"))
    return [outdir / f"{stem}.{ext}" for ext in formats]


def save(fig, stem, dpi=None):
    """Write one figure three ways, remember it, then show it.

    PNG on white for preview; PDF and SVG transparent with editable text, so
    either drops into Illustrator with the labels still real text objects.

    Called at the end of every figure cell. A plain top-to-bottom run therefore
    already writes all three formats of everything into `notebooks/outputs/` —
    you do not have to do anything to get them. `export_figure()` is for when
    you want them somewhere else, in fewer formats, or at a different DPI.
    """
    DRAWN[stem] = fig
    if SAVE:
        _write(fig, stem, OUT, EXPORT_FORMATS, dpi or FIG_DPI)
        print(f"saved: {stem}.{{png,pdf,svg}}")
    return fig


def export_figure(which=None, *, formats=EXPORT_FORMATS, outdir=OUT, dpi=None):
    """Re-export figures that have already been drawn. Nothing is recomputed.

    A normal run already writes `png`, `pdf` and `svg` of every figure into
    `notebooks/outputs/`. Use this when you want something different:

        export_figure()                        # the figure just drawn, again
        export_figure("fig6_pls")              # one, by stem
        export_figure("all")                   # every figure drawn so far
        export_figure("all", outdir="~/Desktop/highconc")
        export_figure("fig4_tuning_by_cluster", formats=("pdf",), dpi=600)

    Parameters
    ----------
    which : str, optional
        A figure's stem, or ``"all"``. Omitted, the most recently drawn figure.
    formats : sequence of str
        Any of ``"png"``, ``"pdf"``, ``"svg"``. PDF and SVG keep live text.
    outdir : path
        Created if missing. `~` is expanded.
    dpi : int, optional
        Raster density for the PNG. Vector formats ignore it.

    Notes
    -----
    Only figures drawn **in this kernel session** can be exported — the figure
    objects live in `DRAWN`. If you restart the kernel, run the notebook again
    first. `"all"` on a fresh kernel says so rather than silently doing nothing.
    """
    outdir = Path(outdir).expanduser()
    bad = [f for f in formats if f not in EXPORT_FORMATS]
    if bad:
        raise ValueError(f"unknown format(s) {bad}; expected any of "
                         f"{list(EXPORT_FORMATS)}")
    if not DRAWN:
        print("nothing drawn in this kernel yet — run the notebook first, "
              "then export.")
        return []
    if which == "all":
        stems = list(DRAWN)
    elif which is None:
        stems = [list(DRAWN)[-1]]
    elif which in DRAWN:
        stems = [which]
    else:
        raise KeyError(f"{which!r} has not been drawn in this session. "
                       f"Available: {sorted(DRAWN)}")

    written = []
    for stem in stems:
        written += _write(DRAWN[stem], stem, outdir, formats, dpi or FIG_DPI)
    print(f"exported {len(stems)} figure(s) x {len(formats)} format(s) "
          f"-> {outdir}")
    return written

# %%
# ---------------------------------------------------------------------------
# EXPORTING FIGURES
#
# You do not need to do anything: a top-to-bottom run already writes png, pdf
# and svg of every figure into `notebooks/outputs/`. The lines below are for
# when you want something else. Uncomment and run one AFTER the notebook has
# been run, so there is something to export.
#
# export_figure("all")                                # everything, again
# export_figure("all", outdir="~/Desktop/highconc")   # somewhere else
# export_figure("all", formats=("pdf",), dpi=600)     # just the vector PDFs
# ---------------------------------------------------------------------------

# %%
# The clustered dataset — 59 odorants x 376 glomeruli at two concentrations,
# with NMF cluster identity and bulb coordinates attached. Ships inside
# glom-explorer; there is no external data path to configure.
d = load(VARIANT)
print(f"{d.n_odorants} odorants x {d.n_gloms} gloms | "
      f"subjects {list(d.subjects)} | clusters 1-{cl.N_CLUSTERS}")

# %%
# The baseline PLS model, fitted once and shared by the figure sections below:
# log1p, mean-centered inside the pipeline, family-stratified 4-fold CV,
# 8 components. `pls.fit` is memoized, so the later sections are free.
m = pls.fit(VARIANT)
print(f"Q2_global = {pls.baseline_q2(m):+.4f} | RMSECV = {pls.baseline_rmse(m):.3f} "
      f"| {m.n_odorants} odorants x {m.n_gloms} gloms")

# %% [markdown]
# ## 2. Figure 2 — odorant tuning across Burton's own glomeruli, three conditions
#
# Three response matrices over the same 59 odorants, this time against
# Burton et al.'s own glomeruli rather than this dataset's 376 — panel A at
# high concentration, B at low, C at the "most sensitive" condition (a
# different, smaller subject/preparation, `omp114L`/`omp8x`, 76 glomeruli
# instead of the other two panels' 113). Rows are grouped by chemical class
# the same way Figure 3's panels are, so the two figures read the same way at
# a glance.
#
# - **A, B, C** — each cell is one odorant-glomerulus pair; brighter means a
#   bigger response. All three panels share one colour scale. Odorants are
#   grouped down the rows by chemical class, with the coloured strip and
#   class names on the left — the same convention as Figure 3's chemical-class
#   strip, just turned 90° onto the row axis since odorants are rows here, not
#   columns. Columns (glomeruli) carry no identity or ordering information
#   supplied with the data and are left unlabeled. Panel C is narrower than A
#   and B only because its source glomerulus population is smaller (76 vs.
#   113) — not a scaling artifact.
#
# High concentration is visibly denser than low — printed under the figure.

# %%
# Own constants — this section inherits no bare name from anywhere, even
# though its legal values mirror §3's.
FIG2_ORDER = "matt"      # chemical-class block order -- highconc.clusters.class_order
FIG2_WITHIN = "burton"   # within-block odorant order -- highconc.clusters.WITHIN_BLOCK_ORDERS
FIG2_CONCS = ("high", "low", "most_sensitive")   # -> panels A, B, C

fig2_mats = [similarity.burton_response_matrix(d, c, order=FIG2_ORDER,
                                               within=FIG2_WITHIN)
            for c in FIG2_CONCS]
for label, mat in zip(FIG2_CONCS, fig2_mats):
    print(f"panel {label!r}: {mat.M.shape[1]} gloms, "
          f"{(mat.M != 0).mean():.1%} of cells nonzero")

# %%
# --- Figure 2 ---------------------------------------------------------------
# A over B over C rather than side by side: every panel is 59 odorants x
# however many gloms it has, so a wide, short box (rather than a squarish
# one) is what lets the glomerulus axis actually read as wider than the
# odorant axis is tall.
FIG2_W_MM, FIG2_H_MM = 200, 250                        # original target print size
# Scale the whole figure down by one factor rather than rebuild its layout,
# solved so the rendered width comes out to exactly MAIN_TARGET_W.
FIG2_SCALE = MAIN_TARGET_W * 25.4 / FIG2_W_MM
FIG2_W_MM, FIG2_H_MM = FIG2_W_MM * FIG2_SCALE, FIG2_H_MM * FIG2_SCALE
FIG2_W, FIG2_H = FIG2_W_MM / 25.4, FIG2_H_MM / 25.4    # -> inches for figsize

fig, axes = plt.subplots(3, 1, figsize=(FIG2_W, FIG2_H), dpi=200,
                         gridspec_kw=dict(left=0.16, right=0.68, top=0.95,
                                          bottom=0.05, hspace=0.30))
im = None
titles = ["'high'", "'low'", "'most sensitive'"]
for ax, mat, title, L in zip(axes, fig2_mats, titles, "ABC"):
    im = P.similarity.response_matrix(ax, mat, title=title, boundaries=False,
                                      strip_fontsize=CLASS_STRIP_FONTSIZE)
    ax.set_title(title, fontsize=HEATMAP_TITLE_FONTSIZE)
    hs.panel_label(ax, L, x=-0.16, y=1.14)
pos_b = axes[1].get_position()
cax = fig.add_axes([0.84, pos_b.y0, 0.03, pos_b.height])
P.similarity.similarity_colorbar(fig, im, cax, label="response")

save(fig, "fig2_response_matrix")
plt.show()

# %% [markdown]
# ## 3. Figure 3 — odorant–odorant response similarity at both concentrations
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# Panels A, B and C ask, for every pair of the 59 odorants, how similar the
# two patterns of glomerular activity are — A at the "most sensitive"
# condition, B at low concentration, C at high. Average similarity between
# different odorants is 0.03 at low and 0.10 at high, and the low/high
# matrices agree with each other at a rank correlation of 0.55.
#
# Panel D is a chemical-structure similarity for the same 59 odorants, which
# does not change with concentration. Chemical similarity tracks response
# similarity more closely at high concentration than at low (rank correlation
# 0.21 → 0.31).
#
# **Reading order is D, A, B, C, left to right** — the fixed chemical ruler
# shown first, then the three concentration-dependent conditions it's judged
# against. A panel's letter stays tied to its content regardless of where
# it's drawn (`FIG3_PANEL_ORDER`), so D is still the chemical-similarity panel
# even though it's leftmost.
#
# **Reading the panels.**
#
# - **A, B, C** — every cell is one odorant pair; brighter means their
#   glomerular response patterns are more alike. All three share one colour
#   scale, so differences between them are not a scaling artifact. Odorants
#   are grouped along both edges by chemical class, with the aromatics split
#   into three finer groups (Ar. Ketone, Ar. Ketone/Ester, Phenol/Methoxy —
#   see below). The grey diagonal is each odorant compared with itself, which
#   is 1 by definition; four odorants (D15, E1, P1, P4) have no data at the
#   "most sensitive" condition, so panel A reads them at the colour floor
#   rather than as a gap. Only **A** carries the chemical-class names under
#   its strip — D, B and C repeat the same coloured strip with no text, so
#   the row of four doesn't say "acids, aldehydes, ..." four times over.
# - **D** — the same pairs, scored on chemical structure (MACCS keys, cosine)
#   instead of on response. Carries the same aromatics breakdown as A–C.
# - **E, F, G** — three individual glomeruli, one per panel. Each bar is one
#   odorant: the low-concentration response points up, the high-concentration
#   response points down. Bar colours are chemical class — the plain, ten-class
#   version; the aromatics split is a panel A–D thing only. The downward bars
#   are magnitudes, not negative numbers.
# - **H** — recruitment. Each row is an odorant that drove a glomerulus at low
#   concentration; each column an odorant that newly drives it at high. The
#   cell is the fraction of that row's glomeruli recruited. Grey is undefined,
#   not zero.
#
# **Panel A's data.** `data/burton_et_al/most_sensitive.csv` and
# `odorant_order.txt`, supplied 2026-09-02 — the "most sensitive" condition
# this dataset didn't otherwise have. The odorant order in that file is now
# also the order every panel here uses (A–H), in place of the odorant table's
# own order.
#
# **The three example glomeruli** are numbers 173, 211 and 97, and Figure 6
# shows the same three. Nothing on record said which glomeruli the original
# panels used, so they were identified by measuring the bars in the draft PDF
# and matching them against all 376; they match to within the PDF's own
# rounding.
#
# **Panel letters follow the figure PDF, not the manuscript text**, which
# disagree — the text calls the recruitment matrix 3E, the PDF calls it 3H.

# %%
CLASS_ORDER_FIG3 = "matt"      # "table" | "matt" | "matt_esters_first"
WITHIN_CLASS_ORDER = "matt"    # "table" | "matt" (pyrazine only) | "burton" (full order)
FIG3_SPLIT_AROMATICS = True    # split "R" into 3 display subclasses on panels A-D
FIG3_PANEL_ORDER = "DABC"      # left-to-right draw order for the top row -- a
                               # panel's letter stays tied to its content
                               # (D is still the MACCS matrix) regardless of
                               # where it's drawn
SPECTRUM_SCALE = "per-panel"   # "per-panel" | "shared"
EG_GLOMERULI = similarity.EG_GLOMERULI     # Fig 6B-D must reuse these
# Fourth example glomerulus (panel H). Not part of EG_GLOMERULI, so Fig 6 is unaffected.
# Position within one mouse, counted from 0 among the glomeruli that survive the
# `nonresponders_dropped` filter.
EXTRA_SUBJECT = 1
EXTRA_GLOM_IN_SUBJECT = 8
EXTRA_GLOM = int(np.flatnonzero(d.subject == EXTRA_SUBJECT)[EXTRA_GLOM_IN_SUBJECT])

# Odorant CODEs (the leading token of `Odorant`), positionally aligned with
# `d`'s native odorant order -- `recruitment_matrix`'s `within` needs these,
# and §6 reuses this same array for its own recruitment call for the same
# reason it reuses CLASS_ORDER_FIG3/WITHIN_CLASS_ORDER.
ODORANT_CODES = np.asarray([s.split()[0] for s in d.odorants["Odorant"].values])

mats = [similarity.most_sensitive_correlation(d, order=CLASS_ORDER_FIG3,
                                              within=WITHIN_CLASS_ORDER),
        similarity.response_correlation(d, "low", order=CLASS_ORDER_FIG3,
                                        within=WITHIN_CLASS_ORDER),
        similarity.response_correlation(d, "high", order=CLASS_ORDER_FIG3,
                                        within=WITHIN_CLASS_ORDER),
        similarity.chemical_similarity(d, order=CLASS_ORDER_FIG3,
                                       within=WITHIN_CLASS_ORDER)]
if FIG3_SPLIT_AROMATICS:
    mats = [similarity.split_block(s, d, "R", cl.AROMATIC_SUBCLASS_BY_CODE)
           for s in mats]
spectra = similarity.eg_spectra(d, [*EG_GLOMERULI, EXTRA_GLOM],
                                order=CLASS_ORDER_FIG3, within=WITHIN_CLASS_ORDER)

shift = similarity.concentration_shift(mats[1], mats[2])
print(f"mean off-diagonal correlation: {shift['mean_low']:.4f} (low) -> "
      f"{shift['mean_high']:.4f} (high), delta {shift['delta']:+.4f}")
print(f"the two matrices agree at Spearman {shift['spearman']:.3f} "
      f"over {shift['n_pairs']} odorant pairs")
for s in spectra:
    print(f"glom {s.glom:3d} (cluster {s.cluster}): "
          f"{int(s.responded.sum()):2d} odorants responding, max {s.limit:.1f}")

# %%
# Panel I's matrix is computed here rather than inherited from §6, so the two
# sections cannot drift and either can be run without the other.
# `recruitment.fit` is memoized, so the second call costs nothing.
# `threshold_effodor` in the lab's original algorithm -- one shared fraction,
# used both to call a glomerulus "tuned" to a low odorant and, on the high
# side, to call it "recruited". `LO_FRAC_FIG3` is the separate, lower bar for
# "not really active at low" that recruitment requires.
ROW_FRAC_FIG3 = 0.20
LO_FRAC_FIG3 = 0.20

rmx3 = rc.recruitment_matrix(m, level="odorant", lo_threshold=LO_FRAC_FIG3,
                             frac=ROW_FRAC_FIG3, order=CLASS_ORDER_FIG3,
                             within=WITHIN_CLASS_ORDER, codes=ODORANT_CODES)
print(f"panel I: rows built from {rmx3.n_rows.mean():.1f} gloms on average; "
      f"{rmx3.n_empty} empty")

# %%
# --- Figure 3 ---------------------------------------------------------------
fig = plt.figure(figsize=(14.0, 11.6), dpi=200)
gs = fig.add_gridspec(3, 4, height_ratios=[1.00, 0.58, 1.55],
                      hspace=0.38, wspace=0.30,
                      left=0.07, right=0.91, top=0.965, bottom=0.045)

# Letter -> (matrix, title), so FIG3_PANEL_ORDER can reorder where each is
# drawn without disturbing which letter names which content.
titles_by_letter = dict(zip("ABCD", ["'most sensitive'", "'low' (1x)",
                                     "'high' (25x)", "MACCS cosine"]))
mats_by_letter = dict(zip("ABCD", mats))
axes_top4 = []
for j, L in enumerate(FIG3_PANEL_ORDER):
    ax = fig.add_subplot(gs[0, j])
    # The x-axis chemical-class strip, with its family names, is drawn on all
    # four panels (they share the same class order).
    im = P.correlation_matrix(ax, mats_by_letter[L], title=titles_by_letter[L],
                              boundaries=False, strip_labels=True)
    hs.panel_label(ax, L, x=-0.16)
    axes_top4.append(ax)
cax = fig.add_axes([0.925, 0.775, 0.010, 0.14])
P.similarity_colorbar(fig, im, cax)

# E-H: one column per spectrum, nested inside the outer row's full span rather
# than the top row's 4 columns.
gs_efg = GridSpecFromSubplotSpec(1, len(spectra), subplot_spec=gs[1, :],
                                 wspace=0.30)
LIM = P.shared_spectrum_limit(spectra) if SPECTRUM_SCALE == "shared" else None
for j, (s, L) in enumerate(zip(spectra, "EFGH")):
    ax = fig.add_subplot(gs_efg[0, j])
    P.response_spectrum(ax, s, limit=LIM,
                        ylabel="Resp. amplitude" if j == 0 else "")
    ax.set_title(f"glomerulus {s.glom} · cluster {s.cluster}",
                 fontsize=hs.FS_LABEL)
    hs.panel_label(ax, L, x=-0.22)

# H gets exactly A-D's rendered box size (not gs[2, :]'s full-width span +
# set_box_aspect(1), which made it much bigger) -- measured off a real A-D
# axes after a draw, since aspect="equal" shrinks their box from the raw
# gridspec cell to a square, and that final size isn't known until then.
fig.canvas.draw()
pos_top = axes_top4[0].get_position()
row2_bbox = gs[2, :].get_position(fig)
h_x0 = (row2_bbox.x0 + row2_bbox.x1) / 2 - pos_top.width / 2
h_y0 = (row2_bbox.y0 + row2_bbox.y1) / 2 - pos_top.height / 2
axH = fig.add_axes([h_x0, h_y0, pos_top.width, pos_top.height])
imH = P.recruitment.matrix(axH, rmx3, "observed",
                           vmax=P.recruitment.shared_vmax(rmx3), ylabel=True,
                           title="binary recruitment matrix (observed)")
hs.panel_label(axH, "I", x=-0.16, y=1.05)
caxH = fig.add_axes([h_x0 + pos_top.width + 0.012, h_y0, 0.010, pos_top.height])
cbH = fig.colorbar(imH, cax=caxH, extend="max")
cbH.set_label("recruitment probability", fontsize=hs.FS_LABEL)
cbH.ax.tick_params(labelsize=hs.FS_TICK)

save(fig, "fig3_correlational_structure")
plt.show()
# export_figure("fig3_correlational_structure")   # -> notebooks/outputs/fig3_correlational_structure.{png,pdf,svg}
# export_figure("fig3_correlational_structure", formats=("pdf",), outdir="~/Desktop")

# %% [markdown]
# ### Supplement to Figure 3 — the recruitment matrix at five cutoffs
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# Panel H depends on one choice: how strongly an odorant must drive a
# glomerulus before that glomerulus counts as assigned to it.
#
# This supplement redraws the matrix at five values of that cutoff. The block
# structure and the observed-vs-predicted correlation change little across
# them.
#
# In the paper's numbering this is its own figure rather than a panel of
# Figure 3, which is why it saves under its own name.

# %%
SWEEP_FRACS_FIG3 = (0.20, 0.35, 0.50, 0.65, 0.80)

sweep3 = rc.matrix_sweep(m, fracs=SWEEP_FRACS_FIG3, level="odorant",
                         lo_threshold=LO_FRAC_FIG3, order=CLASS_ORDER_FIG3)
VMAX_S3 = P.recruitment.shared_vmax(*sweep3)

fig, ax = plt.subplots(2, len(sweep3), figsize=(3.0 * len(sweep3), 6.8), dpi=150)
for j, s in enumerate(sweep3):
    for i, which in enumerate(("observed", "predicted")):
        im = P.recruitment.matrix(ax[i, j], s, which, vmax=VMAX_S3,
                                  tick_labels=None, xlabel=False,
                                  ylabel=False, title="", boundaries=False)
    P.recruitment.matrix_sweep_label(ax[0, j], s)
ax[0, 0].set_ylabel("observed")
ax[1, 0].set_ylabel("predicted (held-out)")
fig.colorbar(im, ax=ax, fraction=0.014, pad=0.02, extend="max",
             label="recruitment probability")
fig.suptitle("Supplement to Figure 3 — the recruitment matrix does not depend "
             "on where the assignment rule is cut", fontsize=13, weight="bold")
save(fig, "fig3_supp_threshold_robustness")
plt.show()
# export_figure("fig3_supp_threshold_robustness")   # -> notebooks/outputs/fig3_supp_threshold_robustness.{png,pdf,svg}
# export_figure("fig3_supp_threshold_robustness", formats=("pdf",), outdir="~/Desktop")

# %%
for s in sweep3:
    print(f"frac={s.frac:.2f}  empty rows={s.n_empty:2d}  "
          f"mean row n={s.n_rows.mean():5.1f}  r_offdiag={s.r_offdiag:.3f}")

# %% [markdown]
# ## 4. Figure 4 — the seven glomerular groups, and tuning by chemical class
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# Every panel is the same 376 glomeruli, shown four ways.
#
# - **A** — every pair of glomeruli, scored on how similar their odorant
#   preferences are, ordered by group. Within-group correlation runs 0.12–0.51
#   against a between-group mean of −0.03. (Grey diagonal = each glomerulus
#   versus itself.) A green box outlines each of the seven diagonal
#   within-group squares.
# - **B** — the response matrix behind that: odorants down, glomeruli across.
#   Brightness is now each glomerulus's response **relative to its own
#   strongest odorant** (0-1, linear), not an absolute ΔF/F on a log scale —
#   so this panel answers "which odorants drive this glomerulus, relative to
#   its own best one," not "how big is this response in absolute terms."
#   Glomerulus columns are still sorted by group (the vertical lines mark
#   where one group's block ends and the next begins); odorant rows run in
#   the plain order Figure 3/6 use instead of being grouped with the columns,
#   so a group's block of columns no longer lines up with a matching block of
#   rows — there's no shaded diagonal square any more, just the vertical
#   group lines. Each of the ten chemical-class row blocks is labelled with
#   its name, the same ten names panel D uses. Most glomerulus–odorant pairs
#   do not respond, so most of the panel is empty; a response below the same
#   floor used elsewhere (1 ΔF/F) still falls through to the grey background,
#   even after normalising — so a glomerulus whose best response never really
#   clears the noise floor reads as empty, not as a falsely "bright" 1.0.
# - **C** — the same data one mouse at a time, for two of the groups, sharing
#   the odorant sort so the panels line up row for row.
# - **D** — rows are chemical classes, columns the seven groups. Each cell
#   counts the glomeruli in that group with a nonzero response to at least
#   one odorant of that class, then scales the column so its top chemical
#   class reads as 1 and the rest are a fraction of it. Low concentration on
#   top, high underneath, each with its own colour scale.
#
# **Which two groups are in panel C.** Group 1, which responds to a mix of
# acids and aldehydes, and group 3, which responds almost only to furans. The
# paper's caption describes this panel as contrasting a mixed group with a
# narrowly selective one, and these two are the clearest such pair that is
# present in all four mice.
#
# **Note for the caption:** it currently names amines as the selective group
# (group 5). Group 5 has no glomeruli at all in mice 3 and 4, so that version
# of the panel had two empty columns; group 3 was substituted. The caption
# needs updating to match, or the panel reverting.
#
# **Panel E is Matt's**, not drawn here.

# %%
# Every constant here is prefixed and owned by this section, so that no two
# sections can share a bare name like `VMIN`/`VMAX` and silently rebind it.
FIG4_VMIN, FIG4_VMAX = 1, 140      # dF/F colour range of the response heatmaps
FIG4_CMAP = "magma"
FIG4_EMPTY = "gainsboro"           # below vmin -> grey
FIG4_BOUNDARY, FIG4_BOUNDARY_ALPHA = "blue", 0.5

FIG4_CONC_A = "low"          # 4A is the low-concentration matrix
FIG4C_CLUSTERS = (1, 3)      # mixed acids/aldehydes cluster, furan cluster
# Reuses §3's own CLASS_ORDER_FIG3 directly (not an independent copy), so "the
# same broad chemical order as Fig 3/6" is guaranteed rather than kept in sync
# by hand -- same coupling §6 already has to §3's class order.
FIG4_CHEM_ORDER = CLASS_ORDER_FIG3
# Toggle for B/C's odorant order *within* each cluster block (columns stay
# glomerulus-cluster-sorted either way -- this only ever touches rows).
# True: chemical class (FIG4_CHEM_ORDER). False: native odorant order, i.e.
# `bicluster_order`'s own chem_order=None default -- ties in the stable sort
# keep their original order, so this is not "no sort", it's "no secondary
# sort key".
FIG4B_SORT_BY_CLASS = True

# Panel B's own row order -- independent of `bic` below, which panel C still
# reads. "cluster": the manuscript default, rows bi-clustered like the
# columns (diagonal block highlight makes sense). "odorant": rows follow
# Fig 3/6's own odorant order (FIG4_CHEM_ORDER/"burton") instead, ignoring
# cluster membership entirely -- a cluster's rows are then scattered, not
# contiguous, so the diagonal highlight is turned off for this mode (wired
# in below via `diagonal_blocks`). Vertical glomerulus-cluster lines draw
# either way -- only the rows move.
FIG4B_ROW_ORDER = "odorant"

# Panels B and C both: peak-normalise each glomerulus (column) to [0, 1] by its
# own max response,
# on the raw dF/F values, and draw on a LINEAR scale instead of log -- the
# two go together (see `biclustered`'s `col_normalize` docstring). `FIG4_VMIN`
# /`FIG4_VMAX` (tuned for raw dF/F on a log scale) do not apply in this mode;
# `FIG4B_NORM_VMIN`/`FIG4B_NORM_VMAX` are panel B's own limits instead.
FIG4B_COL_NORMALIZE = True
FIG4B_NORM_VMIN, FIG4B_NORM_VMAX = 0.0, 1.0
# Restores the "nonzero cutoff" (the same FIG4_VMIN=1 floor the non-normalised
# log view uses) even though column-normalising otherwise erases it: a cell
# whose RAW dF/F was below this never draws on the ramp, however large its
# normalised value would have been -- so a glomerulus whose peak never
# clears the noise floor greys out entirely instead of showing a misleadingly
# "bright" 1.0 for its own weak best odorant. `None` disables this and lets
# every normalised value draw, including noise-floor-weak ones.
FIG4B_RAW_FLOOR = FIG4_VMIN

gsim = similarity.glomerulus_correlation(d, FIG4_CONC_A)
# The block boundaries (and the diagonal alignment with the glomerulus
# columns) are the same regardless of FIG4B_SORT_BY_CLASS; only the order
# inside a block moves. Shared by C (and, when FIG4B_ROW_ORDER="cluster", by
# B too); B reads its own `bic_b` below whenever FIG4B_ROW_ORDER="odorant",
# so C's row order never moves when B's does.
bic = P.clustering.bicluster_order(
    d, chem_order=(FIG4_CHEM_ORDER if FIG4B_SORT_BY_CLASS else None),
    within_order=WITHIN_CLASS_ORDER)
bic_b = P.clustering.bicluster_order(
    d, chem_order=FIG4_CHEM_ORDER, within_order=WITHIN_CLASS_ORDER,
    row_order=FIG4B_ROW_ORDER)

# Panel D's underlying numbers, one row per chemical class, one column per
# cluster -- computed once and reused for both the drawing calls below and
# the CSV export, so the saved numbers are exactly what the panel draws.
_fig4d_low, _fig4d_letters = P.clustering.class_cluster_glom_composition(
    d, "low", FIG4_CHEM_ORDER)
_fig4d_high, _ = P.clustering.class_cluster_glom_composition(
    d, "high", FIG4_CHEM_ORDER)

fig4d_table = pd.concat(
    {conc: pd.DataFrame(matrix, index=_fig4d_letters,
                        columns=[f"cluster_{k}" for k in range(1, 8)])
     for conc, matrix in (("low", _fig4d_low), ("high", _fig4d_high))},
    names=["conc", "chem_class"])
if SAVE:
    fig4d_csv = OUT / "fig4_tuning_by_cluster_D_glom_composition.csv"
    fig4d_table.to_csv(fig4d_csv)
    print(f"saved: {fig4d_csv.relative_to(ROOT)}")

bm = gsim.block_means()
within = np.diag(bm.values)
between = bm.values[~np.eye(len(bm), dtype=bool)]
print(f"panel A: within-cluster correlation {within.min():.2f}-{within.max():.2f}, "
      f"between-cluster mean {between.mean():+.3f}")
for k in FIG4C_CLUSTERS:
    n = [int((d.subject_mask(s) & d.cluster_mask(k)).sum()) for s in d.subjects]
    print(f"panel C: cluster {k} has {sum(n)} glomeruli, {n} per subject")

# %%
# Scale the whole figure by one factor rather than rebuild its gridspec
# math -- every gridspec call below is fraction-based, so it shrinks
# proportionally for free. Solved so the rendered width is MAIN_TARGET_W.
FIG4_SCALE = MAIN_TARGET_W / 14.0
FIG4_W, FIG4_H = 16.0 * FIG4_SCALE, 11.0 * FIG4_SCALE

fig = plt.figure(figsize=(FIG4_W, FIG4_H), dpi=FIG_DPI)

# --- top row: A (square correlation matrix) and B (wide response heatmap) ---
gs_top = fig.add_gridspec(1, 2, width_ratios=[1, 3.1], wspace=0.16,
                          left=0.06, right=0.93, top=0.95, bottom=0.60)
ax_a = fig.add_subplot(gs_top[0, 0])
ax_b = fig.add_subplot(gs_top[0, 1])

im_a = P.clustering.glomerulus_correlation_matrix(
    ax_a, gsim, title={"low": "low", "high": "high"}[FIG4_CONC_A],
    boundaries=False, cluster_boxes=True, cluster_box_color="green")
mesh_b = P.clustering.biclustered(d, ax_b, conc=FIG4_CONC_A, order=bic_b,
                                  diagonal_blocks=(FIG4B_ROW_ORDER == "cluster"),
                                  class_names=True,
                                  col_normalize=FIG4B_COL_NORMALIZE,
                                  raw_floor=(FIG4B_RAW_FLOOR
                                            if FIG4B_COL_NORMALIZE else None),
                                  vmin=(FIG4B_NORM_VMIN if FIG4B_COL_NORMALIZE
                                       else FIG4_VMIN),
                                  vmax=(FIG4B_NORM_VMAX if FIG4B_COL_NORMALIZE
                                       else FIG4_VMAX),
                                  cmap=FIG4_CMAP, empty_color=FIG4_EMPTY,
                                  boundary_color=FIG4_BOUNDARY,
                                  boundary_alpha=FIG4_BOUNDARY_ALPHA)

pos_a = ax_a.get_position()
cax_a = fig.add_axes([pos_a.x0, pos_a.y0 - 0.055, pos_a.width * 0.6, 0.014])
cb_a = fig.colorbar(im_a, cax=cax_a, orientation="horizontal",
                    ticks=[0.0, 0.5, 1.0])
cb_a.set_label(r"correlation $\rho$", fontsize=hs.FS_LABEL)
cb_a.ax.tick_params(labelsize=hs.FS_TICK)
cb_a.outline.set_visible(False)

pos_b = ax_b.get_position()
cax_b = fig.add_axes([pos_b.x1 + 0.012, pos_b.y0, 0.010, pos_b.height * 0.7])
if FIG4B_COL_NORMALIZE:
    # Linear 0-1: each glomerulus's response relative to its own peak, not
    # an absolute ΔF/F -- pairs with `col_normalize` in the draw call above.
    cb_b = fig.colorbar(
        plt.cm.ScalarMappable(
            norm=plt.Normalize(vmin=FIG4B_NORM_VMIN, vmax=FIG4B_NORM_VMAX),
            cmap=hs.sequential_cmap(under=FIG4_EMPTY, bad=FIG4_EMPTY)),
        cax=cax_b)
    cb_b.set_label("resp., rel. to glom. peak", fontsize=hs.FS_LABEL)
    cb_b.set_ticks([0.0, 0.5, 1.0])
    cb_b.set_ticklabels(["0", "0.5", "1"])
else:
    cb_b = fig.colorbar(
        plt.cm.ScalarMappable(norm=LogNorm(vmin=FIG4_VMIN, vmax=FIG4_VMAX),
                              cmap=hs.sequential_cmap(under=FIG4_EMPTY,
                                                      bad=FIG4_EMPTY)),
        cax=cax_b)
    cb_b.set_label("ΔF/F", fontsize=hs.FS_LABEL)
    cb_b.set_ticks([1, 10, 100])
    cb_b.set_ticklabels(["1", "10", "100"])
cb_b.ax.minorticks_off()
cb_b.ax.tick_params(labelsize=hs.FS_TICK)

# --- bottom row: C (two clusters x four subjects) and D (class x cluster) ---
gs_bot = fig.add_gridspec(
    1, 3, width_ratios=[1, 1, 1.15], wspace=0.30,
    left=0.06, right=0.93, top=0.46, bottom=0.06)

# C's rows are B's rows: Fig 3/6's exact 59-odorant order (CLASS_ORDER_FIG3
# blocks, WITHIN_CLASS_ORDER within them), not the cluster-sorted rows `bic`
# carries. Only the rows move: columns stay one cluster's glomeruli per
# subject. C also takes B's peak-normalisation and raw floor, so a glomerulus
# reads identically in both and B's colorbar is C's too.
perm_c, _, _, class_bounds_c = similarity.class_sorted(
    d, CLASS_ORDER_FIG3, WITHIN_CLASS_ORDER)
assert FIG4B_ROW_ORDER == "odorant" and np.array_equal(perm_c, bic_b.rows), \
    "C's rows must be B's rows (FIG4B_ROW_ORDER='odorant', same class/within order)"
bic_c = dataclasses.replace(bic,
                            rows=perm_c,
                            row_boundaries=np.array([], dtype=int),
                            row_edges=np.array([0, len(perm_c)]))
FIG4C_LINE_COLOR, FIG4C_LINE_LW, FIG4C_LINE_ALPHA = "white", 0.6, 0.8

im_c = None
for g, k in enumerate(FIG4C_CLUSTERS):
    inner = GridSpecFromSubplotSpec(1, len(d.subjects), subplot_spec=gs_bot[0, g],
                                    wspace=0.18)
    axes_c = [fig.add_subplot(inner[0, j]) for j in range(len(d.subjects))]
    for j, subj in enumerate(d.subjects):
        im_c = P.clustering.per_subject_heatmap(
            d, axes_c[j], subj, cluster=k, conc=FIG4_CONC_A, order=bic_c,
            col_normalize=FIG4B_COL_NORMALIZE,
            raw_floor=FIG4B_RAW_FLOOR if FIG4B_COL_NORMALIZE else None,
            vmin=FIG4B_NORM_VMIN if FIG4B_COL_NORMALIZE else FIG4_VMIN,
            vmax=FIG4B_NORM_VMAX if FIG4B_COL_NORMALIZE else FIG4_VMAX,
            cmap=FIG4_CMAP, empty_color=FIG4_EMPTY, cluster_labels=False,
            ylabel=("odorants (by chemical class)" if j == 0 else None))
        for b in class_bounds_c:               # line between chemical classes
            axes_c[j].axhline(b - 0.5, color=FIG4C_LINE_COLOR,
                              lw=FIG4C_LINE_LW, alpha=FIG4C_LINE_ALPHA)
    mid = (axes_c[0].get_position().x0 + axes_c[-1].get_position().x1) / 2
    fig.text(mid, axes_c[0].get_position().y1 + 0.045, f"cluster {k}",
             ha="center", va="bottom", fontsize=hs.FS_LABEL,
             color=hs.cluster_color(k))
    fig.text(mid, axes_c[0].get_position().y0 - 0.032, "glomeruli",
             ha="center", va="top", fontsize=hs.FS_TICK)

# D — the class x cluster summary. Each concentration is normalised within itself
# (every cluster column / its own top class, separately for low and high), so low
# and high each get their own colour scale and colorbar.
inner_d = GridSpecFromSubplotSpec(2, 1, subplot_spec=gs_bot[0, 2], hspace=0.30)
ax_d_low = fig.add_subplot(inner_d[0, 0])
ax_d_high = fig.add_subplot(inner_d[1, 0])
summary_kw_4 = dict(class_order=FIG4_CHEM_ORDER, cmap=FIG4_CMAP,
                    empty_color=FIG4_EMPTY, boundary_color=FIG4_BOUNDARY,
                    boundary_alpha=FIG4_BOUNDARY_ALPHA)
mesh_d_low = P.clustering.cluster_summary(d, ax_d_low, conc="low", xlabel=None,
                                          **summary_kw_4)
mesh_d_high = P.clustering.cluster_summary(d, ax_d_high, conc="high",
                                           **summary_kw_4)

pos_dl = ax_d_low.get_position()
d4_label = "responding glomeruli, relative to cluster's top class"
for ax_d, mesh_d in ((ax_d_low, mesh_d_low), (ax_d_high, mesh_d_high)):
    pos_d = ax_d.get_position()
    cax_d = fig.add_axes([pos_d.x1 + 0.012, pos_d.y0, 0.010, pos_d.height])
    cb_d = fig.colorbar(mesh_d, cax=cax_d)
    cb_d.set_label(d4_label, fontsize=hs.FS_LABEL)
    cb_d.ax.tick_params(labelsize=hs.FS_TICK)

hs.panel_label(ax_a, "A", x=-0.22, y=1.12)
hs.panel_label(ax_b, "B", x=-0.035, y=1.06)
fig.text(0.02, 0.48, "C", fontsize=hs.FS_LABEL + 4, weight="bold", va="top")
fig.text(pos_dl.x0 - 0.055, 0.48, "D", fontsize=hs.FS_LABEL + 4,
         weight="bold", va="top")

save(fig, "fig4_tuning_by_cluster")
plt.show()
# export_figure("fig4_tuning_by_cluster")   # -> notebooks/outputs/fig4_tuning_by_cluster.{png,pdf,svg}

# %% [markdown]
# ## 5. Figure 5 — the seven groups on the dorsal bulb
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# Each map is the same view of the dorsal bulb, with all four mice overlaid
# (the field of view is consistent between them). One group is highlighted per
# map, coloured by mean response at low concentration; every other glomerulus
# is the pale grey background. Groups differ in how spatially compact they are.
#
# **About the colour scale.** It tops out below the brightest glomeruli, so
# about 5% of them saturate. Scaling to the single brightest glomerulus instead
# puts the median glomerulus at 8% of the ramp and the maps read as near-empty.
# It is a **low-concentration** scale: at high concentration about half the
# glomeruli would exceed it.
#
# **Only panel A is ours.** B, C and D in the paper are Matt's bulb
# photographs.

# %%
# Membership only: every cluster member is one solid colour, and no response
# value is drawn -- so there is no concentration to choose and no colourbar.
FIG5_MEMBER_COLOR = "red"
FIG5_NONRESPONDER = "hollow"        # or "context"/"requested", or a dict of scatter kwargs
FIG5_CLUSTER_EDGE = "black"         # see below

# This section has no heatmap panel to key off (see §1), so it gets its own
# scale rather than reading FIG_SCALE directly, solved for MAIN_TARGET_W.
# `_fig5_k` is how much smaller that makes the page than it was under the
# old bare-FIG_SCALE sizing -- marker size (area, so k**2) and linewidth
# (linear, so k) are rescaled by it too, or a page this much smaller would
# leave 7 giant, overlapping dots per row instead of 7 legible clusters.
FIG5_SCALE = MAIN_TARGET_W / 16.0
_fig5_k = FIG5_SCALE / FIG_SCALE
FIG5_CLUSTER_SIZE = 62 * _fig5_k ** 2   # the cluster's own points, drawn on top
FIG5_CLUSTER_LW = 0.6 * _fig5_k
FIG5_CONTEXT_SIZE = 16 * _fig5_k ** 2   # "hollow"'s own base size (NONRESPONDER_MARKERS), scaled
FIG5_CONTEXT_LW = 0.4 * _fig5_k

fig = plt.figure(figsize=(16.0 * FIG5_SCALE, 3.6 * FIG5_SCALE), dpi=FIG_DPI)
gs5 = fig.add_gridspec(1, cl.N_CLUSTERS, wspace=0.06,
                       left=0.05, right=0.97, top=0.82, bottom=0.06)
xlim5, ylim5 = P.clustering.bulb_limits(d)

for k in range(1, cl.N_CLUSTERS + 1):
    ax = fig.add_subplot(gs5[0, k - 1])
    P.clustering.topography(
        d, ax, k, color=FIG5_MEMBER_COLOR,
        size=FIG5_CLUSTER_SIZE, edgecolor=FIG5_CLUSTER_EDGE,
        linewidth=FIG5_CLUSTER_LW, nonresponder_marker=FIG5_NONRESPONDER,
        context_size=FIG5_CONTEXT_SIZE, context_linewidth=FIG5_CONTEXT_LW,
        title=f"Cluster {k}")
    ax.set_xlim(*xlim5)
    ax.set_ylim(*ylim5)
    if k == 1:
        hs.panel_label(ax, "A", x=-0.30, y=1.12)

save(fig, "fig5_spatial_by_cluster")
plt.show()
# export_figure("fig5_spatial_by_cluster")   # -> notebooks/outputs/fig5_spatial_by_cluster.{png,pdf,svg}

# %%
for k in range(1, cl.N_CLUSTERS + 1):
    mask = d.cluster_mask(k)
    xy = d.xy[mask]
    spread = float(np.sqrt(((xy - xy.mean(0)) ** 2).sum(1).mean()))
    print(f"cluster {k}: n = {int(mask.sum()):3d}, "
          f"rms spread {spread:6.1f} px about its centroid")

# %% [markdown]
# ## 6. Figure 6 — a linear model of the low → high change
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# One linear model, fitted once across all odorants, predicting
# high-concentration responses. Every prediction shown is **held out**: the
# model is fitted on some odorants and asked about others.
#
# - **A, B, C** — three individual glomeruli, the same three as Figure 3E–G.
#   Measured high-concentration response points up; the model's prediction for
#   the same glomerulus points down. Each panel carries its own x-axis
#   chemical-class names — unlike Figure 3E–G, which only labels the middle
#   panel, all three here are labelled.
# - **D** — the recruitment matrix from Figure 3H, measured on the left and
#   predicted on the right (r = 0.54).
# - **E** — three cartoons, not data: the three forms the weight matrix could
#   take. Every glomerulus scaling only its own response (diagonal only),
#   off-diagonal weights present but unstructured, or off-diagonal weights in
#   blocks. The paper's text refers to these as i, ii and iii.
# - **F** — the weight matrix itself, ordered by group.
#
# **Two caveats about A–C.**
#
# The bars are in **log1p ΔF/F** — the space the model was actually fitted
# and scored on, not the raw units Figure 3E–G uses. That's a deliberate
# choice, not just a default: in raw ΔF/F, one acid's held-out prediction on
# panel B (glomerulus 211) reaches **193.6** against a measured **66.2**,
# which flattens every other bar toward the baseline once the axis
# autoscales to fit it. `FIG6_SPACE = "raw"` restores those units — the same
# ones 3E–G use, so the two figures compare directly — at the cost of that
# flattening; it's one keyword away.
#
# Correlations depend on that choice: the same predictions score r = 0.53 /
# 0.78 / 0.64 on the log scale shown here and r = 0.30 / 0.53 / 0.55 in raw
# ΔF/F — same model, better-looking numbers in the space it was scored in.
# The scale is stated on the axis for that reason.
#
# Predictions near zero still draw a visible bar regardless of scale: above a
# threshold of 0.4 the model has non-zero predictions for 35 / 25 / 51
# odorants against 10 / 11 / 29 measured. The exact counts print underneath
# the figure on every run — a cross-validated linear model essentially never
# predicts exactly zero, so this is the model's behaviour, not a drawing
# artifact.
#
# **The schematic that used to be panel A was dropped**, and the rest moved up
# a letter. E and F were kept because the paper's text refers to them directly
# ("Fig. 6F, i–iii" and "Fig. 6G").

# %%
FIG6_SPACE = "log"              # "log" (the model's own space) | "sqrt" | "raw" (dF/F)
FIG6_GLOMERULI = (211, 97)      # C's two example glomeruli (dataset glomerulus ids)
FIG6_LIMIT = None               # None = autoscale each panel
FIG6_SUPPORT_THRESHOLD = 0.4    # value above which a bar counts as a response
FIG6_CANONICAL = "baseline"
# D shows EVERY weight of W: there is no top-K cut. Only the colour scale is
# clipped (each sign at its own 99th percentile, see below), never the data.

# Same odorant order as Fig 3's E-H, so C reads against them.
fig6_specs = pls.eg_predicted_spectra(m, d, FIG6_GLOMERULI, space=FIG6_SPACE,
                                      order=CLASS_ORDER_FIG3,
                                      within=WITHIN_CLASS_ORDER)
fig6_w = pls.load_weights(FIG6_CANONICAL)
# The smallest nonzero observed high response in the whole dataset, in
# FIG6_SPACE: the line drawn across C's predicted half.
fig6_obs_floor = pls.observed_high_floor(m, space=FIG6_SPACE)

for s in fig6_specs:
    n_obs, n_pred, n_both = s.support(FIG6_SUPPORT_THRESHOLD)
    print(f"6C: glomerulus {s.glom} (cluster {s.cluster}) - "
          f"r = {s.r:.3f} in {s.space} space; above "
          f"{FIG6_SUPPORT_THRESHOLD}: {n_obs} measured, {n_pred} predicted, "
          f"{n_both} both")
print(f"6C: smallest nonzero observed high response ({FIG6_SPACE}): "
      f"{fig6_obs_floor:.4f}")
print(f"6D: W is {fig6_w.real.shape[0]} x {fig6_w.real.shape[1]}, "
      f"all weights shown")

# 6C's own numbers, one row per odorant per glomerulus -- built from the same
# `fig6_specs` the panels draw, so the saved numbers are exactly what's shown.
fig6_c_table = pd.concat(
    {s.glom: pd.DataFrame({
        "odorant": s.names, "class": s.classes,
        "observed": s.observed, "predicted": s.predicted,
     }).assign(cluster=s.cluster, space=s.space, r=s.r)
     for s in fig6_specs},
    names=["glom", "row"])
if SAVE:
    fig6_c_csv = OUT / "fig6_pls_C_prediction_spectra.csv"
    fig6_c_table.to_csv(fig6_c_csv)
    print(f"saved: {fig6_c_csv.relative_to(ROOT)}")

# %%
# One row, in inches: C (two example glomeruli, stacked) | D (W, square, + colourbar).
# The width is MAIN_TARGET_W exactly; the right margin is whatever is left, so
# changing any other width cannot silently change the page width.
FIG6_MARGIN_L, FIG6_MARGIN_TOP, FIG6_MARGIN_BOT = 0.65, 0.55, 0.55
FIG6_C_W, FIG6_C_H, FIG6_C_GAP = 2.25, 0.90, 0.60   # each spectrum, and the gap between
FIG6_COL_GAP = 0.75                                  # between C and D
FIG6_D_SIDE = 2 * FIG6_C_H + FIG6_C_GAP              # D is square, as tall as C's stack
FIG6_CBAR_PAD, FIG6_CBAR_W = 0.40, 0.14
FIG6_MARGIN_R = (MAIN_TARGET_W - FIG6_MARGIN_L - FIG6_C_W - FIG6_COL_GAP
                 - FIG6_D_SIDE - FIG6_CBAR_PAD - FIG6_CBAR_W)
assert FIG6_MARGIN_R > 0.30, f"Fig 6 row does not fit: right margin {FIG6_MARGIN_R:.2f} in"
FIG6_W = MAIN_TARGET_W
FIG6_H = FIG6_MARGIN_TOP + FIG6_D_SIDE + FIG6_MARGIN_BOT


def x6(inches):
    return inches / FIG6_W


def y6(inches):
    return inches / FIG6_H


fig = plt.figure(figsize=(FIG6_W, FIG6_H), dpi=FIG_DPI)
top_in = FIG6_H - FIG6_MARGIN_TOP          # top edge of the row, from the bottom

# --- C: two example glomeruli, experimental high up / predicted high down ----
for j, s in enumerate(fig6_specs):
    y0 = top_in - FIG6_C_H - j * (FIG6_C_H + FIG6_C_GAP)
    ax = fig.add_axes([x6(FIG6_MARGIN_L), y6(y0), x6(FIG6_C_W), y6(FIG6_C_H)])
    P.similarity.prediction_spectrum(
        ax, s, limit=FIG6_LIMIT, strip_labels=True, annotate_r=False,
        observed_floor=fig6_obs_floor)
    # r goes in the title, as in Fig 3's E-H, not inside the axes
    ax.set_title(f"glomerulus {s.glom}  (cluster {s.cluster})    r = {s.r:.2f}",
                 fontsize=HEATMAP_TITLE_FONTSIZE)
    if j == 0:
        hs.panel_label(ax, "C", x=-0.18, y=1.18)

# --- D: the full W, every weight ---------------------------------------------
d_left = FIG6_MARGIN_L + FIG6_C_W + FIG6_COL_GAP
W6 = fig6_w.real
W6_reord, _, bnd6, centers6 = pls.reorder_by_cluster(W6, fig6_w.cluster_number)
# Each sign scaled to its own 99th percentile -- negatives are smaller, and a
# symmetric range washes them out. TwoSlopeNorm keeps 0 on gainsboro. This only
# sets the colour range; every weight is still drawn.
pos6, neg6 = W6_reord[W6_reord > 0], -W6_reord[W6_reord < 0]
norm6 = TwoSlopeNorm(vmin=-(np.percentile(neg6, 99) if neg6.size else 1.0),
                     vcenter=0.0,
                     vmax=(np.percentile(pos6, 99) if pos6.size else 1.0))
ax_d = fig.add_axes([x6(d_left), y6(FIG6_MARGIN_BOT),
                     x6(FIG6_D_SIDE), y6(FIG6_D_SIDE)])
P.pls.weight_blocks(ax_d, W6_reord, bnd6, centers6, norm=norm6,
                    title="W (low → high concentration mapping)")
hs.panel_label(ax_d, "D", x=-0.11, y=1.05)
cax_d = fig.add_axes([x6(d_left + FIG6_D_SIDE + FIG6_CBAR_PAD),
                      y6(FIG6_MARGIN_BOT + FIG6_D_SIDE * 0.22),
                      x6(FIG6_CBAR_W), y6(FIG6_D_SIDE * 0.56)])
cb_d = fig.colorbar(plt.cm.ScalarMappable(cmap=hs.DIV, norm=norm6), cax=cax_d,
                    extend="both")
cb_d.set_label("W weight", fontsize=hs.FS_LABEL)
cb_d.ax.tick_params(labelsize=hs.FS_TICK)

save(fig, "fig6_pls")
plt.show()
# export_figure("fig6_pls")   # -> notebooks/outputs/fig6_pls.{png,pdf,svg}

# %% [markdown]
# ## 7. Figure 7 — directional transfer of tuning between groups
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# **The test.** Predict a group's high-concentration responses from its own
# low-concentration average — that is the baseline. Then add a second group's
# low-concentration average and see whether the prediction improves. Repeat for
# every ordered pair, in both directions. Prediction is scored on held-out
# odorants, so an improvement is not simply the result of adding a parameter.
#
# - **Left panels** — the permutation *p* for each pair, against 10,000
#   shuffles. A **black box** marks pairs surviving Benjamini–Hochberg
#   correction at q < 0.05.
# - **Right panels** — the size of each improvement, as a percentage of the
#   error the target's own average left behind. Most cells are near zero.
#
# **Two groupings.** The top row groups glomeruli by the seven NMF clusters;
# the bottom row groups them by the chemical class each glomerulus prefers,
# which does not use the clustering. Seven of the eight significant cluster
# results have a counterpart in the class analysis.
#
# **One thing not to misread.** In the bottom-right panel the furan row is
# strongly coloured in the negative direction. Furan-preferring glomeruli have
# a negative intra-group baseline (Q² = −0.08), so the percentage runs against
# a negative denominator. None of those cells is boxed.
#
# **The explanatory header in the paper's version is Matt's**, not drawn here.

# %%
FIG7_METRIC = "pct_err"      # "pct_err" (default) | "pct_var" | "dq2"
FIG7_ALPHA = 0.05            # BH-FDR level; the black boxes
FIG7_CLIP = 0.1              # p above this is the palest cell — colour only
FIG7_NULL = "broken_pairing"  # the published null; see the markdown above
FIG7_MIN_CLASS = 15          # glomeruli a chemical class needs to be tested
FIG7_BOX_COLOR = "#2b9743"   # the box on significant cells (green)
FIG7_P_CMAP = "OrRd"         # A keeps the original sequential ramp (hs.SEQ is magma now)
FIG7_XLABEL = "cluster (predicted at high)"
FIG7_YLABEL = "added non-source cluster\nprediction improvement"

fig7_clusters = transfer.pairwise(m, "clusters", alpha_fdr=FIG7_ALPHA,
                                  null=FIG7_NULL)
fig7_classes = transfer.pairwise(m, "chem_class", alpha_fdr=FIG7_ALPHA,
                                 null=FIG7_NULL)

for t in (fig7_clusters, fig7_classes):
    s = t.summary(FIG7_ALPHA)
    print(f"{s['grouping']:>11}: {s['n_significant']} of {s['n_pairs']} "
          f"ordered pairs at q < {FIG7_ALPHA} "
          f"({s['n_one_way']} one-way), N = {s['n_perm']:,}")
print()
print(P.transfer.edge_table(fig7_clusters, alpha=FIG7_ALPHA,
                            metric=FIG7_METRIC))

# %%
# One row: A and B, the cluster analysis. The chemical-class control (what
# were C and D) is no longer drawn; it is still computed, printed and checked
# in the cells below.
# Scale the whole figure by one factor, solved so the rendered width is
# MAIN_TARGET_W.
FIG7_SCALE = MAIN_TARGET_W / 13.0
FIG7_W, FIG7_H = 13.0 * FIG7_SCALE, 6.0 * FIG7_SCALE
fig = plt.figure(figsize=(FIG7_W, FIG7_H), dpi=FIG_DPI)

gs7 = fig.add_gridspec(1, 2, left=0.09, right=0.90, top=0.82, bottom=0.17,
                       wspace=0.42)

# Only the significant squares carry a number, and they are boxed in green.
ax_p = fig.add_subplot(gs7[0, 0])
P.transfer.pvalue_matrix(ax_p, fig7_clusters, alpha=FIG7_ALPHA, clip=FIG7_CLIP,
                         xlabel=FIG7_XLABEL, ylabel=FIG7_YLABEL, cmap=FIG7_P_CMAP,
                         box_color=FIG7_BOX_COLOR, text_significant_only=True)
hs.panel_label(ax_p, "A", x=-0.26, y=1.12)

ax_m = fig.add_subplot(gs7[0, 1])
P.transfer.improvement_matrix(ax_m, fig7_clusters, metric=FIG7_METRIC,
                              alpha=FIG7_ALPHA, xlabel=FIG7_XLABEL, ylabel="",
                              box_color=FIG7_BOX_COLOR,
                              text_significant_only=True)
hs.panel_label(ax_m, "B", x=-0.16, y=1.12)
P.transfer.significance_legend(ax_m, fig7_clusters, alpha=FIG7_ALPHA,
                               loc=(1.02, -0.16), box_color=FIG7_BOX_COLOR)

fig.text(0.5, 0.98, "Motif transfer between glomerular groups "
                    f"(broken-pairing null, N = {fig7_clusters.n_perm:,})",
         ha="center", va="top", fontsize=hs.FS_TITLE + 1)

save(fig, "fig7_motif_transfer")
plt.show()
# export_figure("fig7_motif_transfer")   # -> notebooks/outputs/fig7_motif_transfer.{png,pdf,svg}

# %%
# The control's actual claim, checked rather than asserted: each significant
# cluster edge is looked up against the class edge between the two clusters'
# dominant preferred classes. Seven of eight should match. If this ever prints
# fewer, the two analyses have drifted apart — which is exactly what the
# control exists to detect.
fig7_match = transfer.matching_edges(fig7_clusters, fig7_classes, m,
                                     alpha=FIG7_ALPHA)
print(f"{'cluster edge':>16}  {'ΔQ²':>8}  {'via':>26}  chemical-class counterpart")
for row in fig7_match:
    e, c = row["cluster_edge"], row["counterpart"]
    via = f"{row['via'][0]} → {row['via'][1]}"
    tail = (f"{c['dq2']:+.4f}  (q = {c['q']:.4f})" if c else "— none —")
    print(f"{e['source'] + ' → ' + e['target']:>16}  {e['dq2']:+8.4f}  "
          f"{via:>26}  {tail}")
n_match = sum(r["counterpart"] is not None for r in fig7_match)
print(f"\n{n_match} of {len(fig7_match)} cluster edges have a class counterpart")

# %%
# Per-group intra baselines — the denominator of both percentage readings, and
# the reason `pct_var` is not the default: cluster 5 is predicted from its own
# mean at Q² = 0.046 and cluster 2 at 0.438, so the same absolute increment
# would read ten times larger on one than on the other.
for t in (fig7_clusters, fig7_classes):
    print(f"{t.grouping.id:>11} intra Q²: " +
          "  ".join(f"{lab}={q:.3f}"
                    for lab, q in zip(t.labels, t.q2_intra)))
print(f"\nchemical classes tested: {list(fig7_classes.labels)}")
print(f"glomeruli excluded (class below n = {FIG7_MIN_CLASS}): "
      f"{fig7_classes.grouping.dropped} of {m.n_gloms}")

# %% [markdown]
# ## 8. Figure S1 — how the number of groups was chosen
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# Seven at low concentration (top row, **A–C**) and five at high (bottom row,
# **D–F**).
#
# - **A / D** — cumulative variance explained against the number of groups, for
#   PCA, PCA on shuffled data, and NMF. The gap between the real and shuffled
#   curves is the structure not attributable to chance.
# - **B / E** — the slope of A: how much each additional group adds.
# - **C / F** — adjusted Rand index across 50 NMF runs from different random
#   starts, measuring how stable the grouping is to the seed. The insets are
#   consensus matrices at the chosen number and at one past it.
#
# **This one is slow and is cached.** The underlying sweep takes minutes, so it
# is stored on disk and read back. If the cache is missing the notebook stops
# with an error rather than recomputing, because a recomputed number might
# differ from the paper's.

# %%
# Own constants — this section inherits no bare name from anywhere.
SUPP_DIM_K_VALUES = list(range(1, 21))   # the sweep on disk; changing this invalidates it
SUPP_DIM_N_SEEDS, SUPP_DIM_N_SHUFFLES = 50, 20
SUPP_DIM_ROWS = [
    # (conc, cache dir, consensus k's, chosen k, panel letters)
    ("1x",  FIGURES / "nmf_dim_choice_1x" / "data" / "cache",  [7, 9], 7, "ABC"),
    # The 25x block (panels D-F) is no longer drawn. Its sweep cache is still on
    # disk under figures/nmf_dim_choice_25x/ and is simply not read here.
]
# One block now, so the 12.5in-tall two-block hand layout is cut to 5.5in; the
# whole thing is scaled so the width is exactly SUPP_TARGET_W, proportions held.
SUPP_DIM_SCALE = SUPP_TARGET_W / 9.0
SUPP_DIM_W, SUPP_DIM_H, SUPP_DIM_DPI = 9.0 * SUPP_DIM_SCALE, 5.5 * SUPP_DIM_SCALE, 300

fig = plt.figure(figsize=(SUPP_DIM_W, SUPP_DIM_H), dpi=SUPP_DIM_DPI)
# One block (the 1x concentration). Inside a block the layout is the retired
# per-concentration figure's: the
# two line panels on top, then a bottom strip holding the ARI curve and the
# stacked consensus matrices, whose height matches the original 7 x 1.75-inch
# rectangle.
gs_rows = fig.add_gridspec(len(SUPP_DIM_ROWS), 1, hspace=0.32)

for row, (conc, cache_dir, consensus_ks, chosen, letters) in enumerate(SUPP_DIM_ROWS):
    sweep, consensus = dimsweep.load_cached(cache_dir, conc=conc, ks=consensus_ks)

    gs_block = gs_rows[row].subgridspec(2, 1, height_ratios=[2, 1], hspace=0.40)
    gs_top = gs_block[0].subgridspec(1, 2, wspace=0.40)
    gs_bot = gs_block[1].subgridspec(1, 6, width_ratios=[0.65] * 5 + [1.0],
                                     wspace=0.20)

    ax_var = fig.add_subplot(gs_top[0, 0])
    P.dimchoice.variance_explained(sweep, ax_var, n_nmf_seeds=SUPP_DIM_N_SEEDS,
                                   n_shuffles=SUPP_DIM_N_SHUFFLES)
    ax_slope = fig.add_subplot(gs_top[0, 1])
    P.dimchoice.variance_slope(sweep, ax_slope)
    # The ARI curve stops before the consensus column so it does not run under
    # the matrices.
    ax_ari = fig.add_subplot(gs_bot[0, 0:5])
    P.dimchoice.stability(sweep, ax_ari, n_nmf_seeds=SUPP_DIM_N_SEEDS)

    inner = GridSpecFromSubplotSpec(len(consensus_ks), 1,
                                    subplot_spec=gs_bot[0, 5], hspace=0.30)
    for i, k in enumerate(consensus_ks):
        P.dimchoice.consensus(consensus[k], fig.add_subplot(inner[i, 0]))

    for ax, letter in zip((ax_var, ax_slope, ax_ari), letters):
        hs.panel_label(ax, letter)
    ax_var.set_title(f"{conc} concentration — chosen k = {chosen}",
                     fontsize=hs.FS_PANEL, loc="left")

    print(f"{conc}: k = {sweep.k_values.tolist()} | chosen k = {chosen} | "
          f"consensus shown at {consensus_ks} | panels {'/'.join(letters)}")

save(fig, "supp_nmf_dim_choice", dpi=SUPP_DIM_DPI)
plt.show()
# export_figure("supp_nmf_dim_choice")   # -> notebooks/outputs/supp_nmf_dim_choice.{png,pdf,svg}

# %% [markdown]
# ## 9. Figure S2 — the same structure within each mouse
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# Figure 4 pools glomeruli from four mice. This shows the same structure
# computed within each animal separately.
#
# - **A** — each mouse's own glomeruli, sorted the same way.
# - **B** — where each group sits on the bulb, one mouse per row and one group
#   per column, over a grey backdrop of every glomerulus from every animal so
#   all 28 maps share a frame.
#
# Group 5's maps are empty for two of the mice, which have no glomeruli in that
# group.
#
# **If you are comparing against an older version of this figure:** the source
# page labels the groups A–G and this one numbers them 1–7. The letters do not
# map onto the numbers in order.

# %%
# Own constants — this section inherits no bare name from anywhere.
# Two separate figures: A (per-subject heatmaps) and B (per-subject maps).
SUPP_SUBJ_DPI = 200
SUPP_SUBJ_LABEL_FS = 7
SUPP_SUBJ_SCALE = SUPP_TARGET_W / 12.5
_supp_subj_k = SUPP_SUBJ_SCALE / (HEATMAP_IN / 2.352)   # vs. this section's old scale
SUPP_SUBJ_TITLE_PAD = 22 * _supp_subj_k   # lifts 'S1'..'S4' clear of the 1-7 cluster row
# A: raw dF/F on a log scale, odorant rows in Fig 3 / Fig 4's chemical-class order.
SUPP_SUBJ_HEAT_VMIN, SUPP_SUBJ_HEAT_VMAX = 1.0, 140.0
SUPP_SUBJ_CMAP = "magma"
SUPP_SUBJ_ODOR_ORDER = CLASS_ORDER_FIG3        # "matt", the same blocks as Fig 3 and Fig 4C
SUPP_SUBJ_ODOR_WITHIN = WITHIN_CLASS_ORDER     # "matt", within each block

# Shared odorant row sort: chemical-class blocks in the Fig 3 order, so these
# panels line up with the Fig 3 matrices. The columns stay sorted by cluster.
# The row boundaries are cleared -- they were odorant-cluster lines, which no
# longer correspond to the rows.
_perm, *_ = similarity.class_sorted(d, SUPP_SUBJ_ODOR_ORDER, SUPP_SUBJ_ODOR_WITHIN)
supp_subj_order = dataclasses.replace(
    P.clustering.bicluster_order(d),
    rows=_perm,
    row_boundaries=np.array([], dtype=int),
    row_edges=np.array([0, len(_perm)]),
)

# %%
# --- Figure S2A: per-subject heatmaps ---------------------------------------
# Canvas in the original 12.5in-wide units (3.6in tall: the old A block plus its
# title room), scaled so the width is exactly SUPP_TARGET_W.
SUPP_SUBJ_W, SUPP_SUBJ_H = 12.5 * SUPP_SUBJ_SCALE, 3.6 * SUPP_SUBJ_SCALE
fig = plt.figure(figsize=(SUPP_SUBJ_W, SUPP_SUBJ_H), dpi=SUPP_SUBJ_DPI)

gs_heat = fig.add_gridspec(1, 4, left=0.11, right=0.97, top=0.767, bottom=0.097,
                           wspace=0.14)
ax_heat = [fig.add_subplot(gs_heat[0, i]) for i in range(4)]
for ax, s in zip(ax_heat, d.subjects):
    P.clustering.per_subject_heatmap(d, ax, s, conc="low",
                                     order=supp_subj_order,
                                     cmap=SUPP_SUBJ_CMAP,
                                     vmin=SUPP_SUBJ_HEAT_VMIN,
                                     vmax=SUPP_SUBJ_HEAT_VMAX,
                                     boundary_color="white")
    # The subject title and the coloured cluster numbers both live above the
    # axes and were landing on the same line. The numbers are written by the
    # panel just above the data; the title is lifted clear of them here.
    ax.set_title(ax.get_title(), fontsize=7, pad=SUPP_SUBJ_TITLE_PAD)
ax_heat[0].set_ylabel("odorants\n(by chemical class)", fontsize=5)
ax_heat[0].yaxis.set_label_coords(-0.16, 0.5)   # clear of the class strip

# Chemical-class strip on the leftmost heatmap only, in the plotted row order.
_row_cls = d.chem_class[supp_subj_order.rows]
_cls_name = {c: cl.class_name(c) for c in dict.fromkeys(_row_cls)}
hs.class_strip(ax_heat[0], [_cls_name[c] for c in _row_cls],
               colors={_cls_name[c]: cl.class_color(c) for c in _cls_name},
               orientation="y", labels=False)

# The colourbar is shortened to 70% of the panel height and centred on it. It
# sits left of the y-label, which sits left of the class strip.
p0 = ax_heat[0].get_position()
_cb_h = p0.height * 0.70
cax = fig.add_axes([0.030, p0.y0 + (p0.height - _cb_h) / 2, 0.012, _cb_h])
cb = fig.colorbar(plt.cm.ScalarMappable(
    norm=LogNorm(SUPP_SUBJ_HEAT_VMIN, SUPP_SUBJ_HEAT_VMAX),
    cmap=SUPP_SUBJ_CMAP), cax=cax)
cax.yaxis.set_ticks_position("left")
cax.yaxis.set_label_position("left")
cb.set_label("\u0394F/F", fontsize=10)
cb.set_ticks([1, 10, 100])
cb.set_ticklabels(["1", "10", "100"])
cb.ax.tick_params(labelsize=8)
cb.ax.minorticks_off()
cb.outline.set_visible(False)

save(fig, "supp_per_subject_heatmaps", dpi=SUPP_SUBJ_DPI)
plt.show()
# export_figure("supp_per_subject_heatmaps")   # -> notebooks/outputs/supp_per_subject_heatmaps.{png,pdf,svg}

# %%
# --- Figure S2B: where each mouse's members of each cluster sit -------------
# Drawn exactly like Fig 5: the same page scale (so each map is Fig 5's size),
# the same marker sizes, black outline on the members and the same pale hollow
# context. Restated here, not read from §5, so each section runs on its own.
# Only the fill differs: it changes with the cluster, as Fig 5's red does not.
SUPP_SUBJ_TOPO_SCALE = MAIN_TARGET_W / 16.0
_supp_topo_k = SUPP_SUBJ_TOPO_SCALE / FIG_SCALE
SUPP_SUBJ_CLUSTER_EDGE = "black"
SUPP_SUBJ_CLUSTER_SIZE = 62 * _supp_topo_k ** 2
SUPP_SUBJ_CLUSTER_LW = 0.6 * _supp_topo_k
SUPP_SUBJ_CONTEXT_COLOR = P.clustering.CONTEXT_COLOR   # "darkgray", as Fig 5's hollow dots
SUPP_SUBJ_CONTEXT_ALPHA = 0.5
SUPP_SUBJ_CONTEXT_SIZE = 16 * _supp_topo_k ** 2
SUPP_SUBJ_CONTEXT_LW = 0.4 * _supp_topo_k
SUPP_SUBJ_TOPO_H = 5.2      # 4 mice, each map about as tall as Fig 5's, plus the title row

supp_subj_limits = P.clustering.bulb_limits(d)      # shared spatial frame

fig = plt.figure(figsize=(MAIN_TARGET_W, SUPP_SUBJ_TOPO_H), dpi=SUPP_SUBJ_DPI)
gs_topo = fig.add_gridspec(4, cl.N_CLUSTERS, left=0.07, right=0.97, top=0.92,
                           bottom=0.02, wspace=0.06, hspace=0.06)
for si, s in enumerate(d.subjects):
    for j, number in enumerate(range(1, cl.N_CLUSTERS + 1)):
        P.clustering.per_subject_topography(
            d, fig.add_subplot(gs_topo[si, j]), s, number,
            limits=supp_subj_limits,
            size=SUPP_SUBJ_CLUSTER_SIZE, edgecolor=SUPP_SUBJ_CLUSTER_EDGE,
            linewidth=SUPP_SUBJ_CLUSTER_LW,
            context_color=SUPP_SUBJ_CONTEXT_COLOR,
            context_alpha=SUPP_SUBJ_CONTEXT_ALPHA,
            context_size=SUPP_SUBJ_CONTEXT_SIZE,
            context_linewidth=SUPP_SUBJ_CONTEXT_LW,
            empty_fontsize=8,
            title=(si == 0),                     # cluster number on row 1 only
            ylabel=(f"S{s}" if j == 0 else None))

save(fig, "supp_per_subject_topography", dpi=SUPP_SUBJ_DPI)
plt.show()
# export_figure("supp_per_subject_topography")   # -> notebooks/outputs/supp_per_subject_topography.{png,pdf,svg}

# %% [markdown]
# ## 11. Figure S4 — predicted vs measured, at three levels of averaging
#
# > **[Caption not yet updated for the merged figure — see notes/merge_decisions.md]**
#
#
# In each panel the horizontal axis is what was measured and the vertical axis
# is what the model predicted; perfect prediction would put every point on the
# diagonal.
#
# - **A** — averaged by group and odorant. *r* = 0.80.
# - **B** — averaged by group and chemical class. *r* = 0.89.
# - **C** — every individual glomerulus–odorant pair, unaveraged, as a density
#   plot. *Q²* = 0.27 over 3,405 responding pairs.
#
# The three are the same predictions at three levels of averaging, and the fit
# is looser the less averaging is applied.
#
# A fourth view, averaging by glomerulus, is not shown: its *r* is near 1 by
# construction, since mean-centring guarantees it.
#
# **Where this figure comes from.** These three panels sat loose on a page of
# the draft under "Not sure about where these figure panels should go ???".
# They are referenced in the text, so they were collected into this supplement.
#
# The draft's version of panel C annotates the statistic as R²; it is computed
# out-of-fold, so it is written here as Q². The value is the same to three
# decimals.

# %%
# Own constants — this section inherits no bare name from anywhere.
# Only panel C of the old three-panel figure remains: the parity of every
# responding glomerulus x odorant pair, observed vs held-out predicted.
SUPP_PAR_C_CMAP = "Purples"          # hexbin colormap
SUPP_PAR_W, SUPP_PAR_H, SUPP_PAR_DPI = SUPP_TARGET_W / 2, 2.4, 200

# The smallest nonzero observed high response in the whole dataset (log1p
# space, which is this panel's space): the dotted horizontal line. A predicted
# value under it is lower than any response the experiment ever measured.
supp_par_floor = pls.observed_high_floor(m, space="log")

fig, ax = plt.subplots(1, 1, figsize=(SUPP_PAR_W, SUPP_PAR_H),
                       dpi=SUPP_PAR_DPI, constrained_layout=True)
# Bare call = the pinned framing at its defaults, which is the draft's panel.
supp_par_hb = P.pls.responding_parity(
    ax, m, cbar=True, title="all responding pairs", title_fontsize=11.5,
    cmap=SUPP_PAR_C_CMAP, floor=supp_par_floor)

print(f"responding pairs   Q2 = {pls.baseline_q2(m):.3f}  "
      f"(n = {pls.responding_pairs(m)[0].size:,}); "
      "the draft page labels this same value R2")
print(f"dotted line at the smallest nonzero observed response: "
      f"{supp_par_floor:.4f} (log1p dF/F)")

save(fig, "supp_parity", dpi=SUPP_PAR_DPI)
plt.show()
# export_figure("supp_parity")   # -> notebooks/outputs/supp_parity.{png,pdf,svg}

# %% [markdown]
# ---
#
# **Note.** Every figure is now in `notebooks/outputs/` as PNG, PDF and SVG, and
# a second, SVG-only copy is in `joel_figures/` at the repo root.
#
# The PDFs and SVGs have transparent backgrounds and live, editable text — open
# one in Illustrator or Inkscape and the labels are still text objects you can
# restyle or move.
#
# To put copies somewhere else, uncomment an `export_figure(...)` line — there
# is one under each figure, and a general one near the top of the notebook.
#
# **If you want to change something:** a panel's contents live in
# `highconc/panels/`, a figure's layout lives in the cell that builds it, and
# fonts and colours live in `highconc/style.py`.
